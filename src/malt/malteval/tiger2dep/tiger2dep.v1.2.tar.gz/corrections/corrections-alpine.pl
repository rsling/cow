
%correct_poscat(471,8,piat).

%correct_edge_label(53,5,hd).

%correct_attachment(85,12,504).

%unnecessary_node(143,506).

%additional_node(node(445,510,504,'$phrase','$phrase',oc,vp,[])).

%correct_surf(401,13,'...').

correct_poscat(848,1,nn).
correct_poscat(859,500,vp).
correct_poscat(994,12,vafin).
correct_poscat(1058,503,avp).

correct_edge_label(2,4,pnc).
correct_edge_label(96,15,ac).
correct_edge_label(97,13,oc).
correct_edge_label(176,509,mnr).
correct_edge_label(393,8,ac).
correct_edge_label(448,506,pd).
correct_edge_label(520,516,pd).
correct_edge_label(549,11,uc).
correct_edge_label(549,13,uc).
correct_edge_label(549,15,uc).
correct_edge_label(549,17,uc).
correct_edge_label(585,6,mo).
correct_edge_label(770,521,oa).
correct_edge_label(859,1,hd).
correct_edge_label(862,510,da).
correct_edge_label(1058,501,hd).

correct_attachment(45,10,522).
correct_attachment(45,13,522).
correct_attachment(45,501,522).
correct_attachment(176,506,509).
correct_attachment(176,509,511).
correct_attachment(185,24,517).
correct_attachment(185,505,517).
correct_attachment(379,17,544).
correct_attachment(379,502,544).
correct_attachment(379,529,544).
correct_attachment(379,530,544).
correct_attachment(499,14,511).
correct_attachment(499,505,511).
correct_attachment(770,521,516).
correct_attachment(994,12,503).
correct_attachment(994,501,503).

additional_node(node(45,522,509,'$phrase','$phrase',oc,vp,[])).
additional_node(node(185,517,507,'$phrase','$phrase',oc,vp,[])).
additional_node(node(379,544,522,'$phrase','$phrase',oc,vp,[])).
additional_node(node(499,511,506,'$phrase','$phrase',oc,vp,[])).

unnecessary_node(176,510).
unnecessary_node(770,515).
unnecessary_node(994,502).











