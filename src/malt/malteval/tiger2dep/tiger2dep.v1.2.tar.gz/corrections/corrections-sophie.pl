correct_poscat(47,1,piat).
correct_poscat(58,23,ptkant).
correct_poscat(106,2,piat).
correct_poscat(113,5,piat).
correct_poscat(120,8,piat).
correct_poscat(138,4,piat).
correct_poscat(143,17,vvfin).
correct_poscat(144,2,piat).
correct_poscat(149,3,piat).
correct_poscat(149,17,piat).
correct_poscat(152,2,piat).
correct_poscat(184,5,piat).
correct_poscat(218,3,piat).
correct_poscat(222,10,piat).
correct_poscat(235,5,piat).
correct_poscat(242,6,piat).
correct_poscat(265,12,pis).
correct_poscat(277,1,piat).
correct_poscat(278,16,piat).
correct_poscat(282,16,piat).
correct_poscat(283,6,piat).
correct_poscat(285,6,piat).
correct_poscat(286,11,piat).
correct_poscat(287,3,piat).
correct_poscat(292,3,piat).
correct_poscat(292,17,piat).
correct_poscat(295,1,piat).
correct_poscat(297,8,piat).
correct_poscat(300,4,piat).
correct_poscat(301,28,piat).
correct_poscat(306,8,piat).
correct_poscat(308,1,piat).
correct_poscat(308,7,piat).
correct_poscat(310,8,piat).
correct_poscat(312,10,piat).
correct_poscat(314,4,piat).
correct_poscat(323,24,card).
correct_poscat(325,1,piat).
correct_poscat(327,16,piat).
correct_poscat(334,1,piat).
correct_poscat(353,17,piat).
correct_poscat(367,14,piat).
correct_poscat(367,27,piat).
correct_poscat(379,1,piat).
correct_poscat(380,2,piat).
correct_poscat(423,4,piat).
correct_poscat(424,1,piat).
correct_poscat(445,4,vvpp).
correct_poscat(446,8,piat).
correct_poscat(446,14,piat).
correct_poscat(447,6,piat).
correct_poscat(450,1,piat).
correct_poscat(451,2,piat).
correct_poscat(471,8,piat).

correct_edge_label(53,5,hd).
correct_edge_label(53,500,ng).
correct_edge_label(58,23,hd).
correct_edge_label(58,502,dm).
correct_edge_label(59,505,da).
correct_edge_label(75,12,hd).
correct_edge_label(75,501,ng).
correct_edge_label(76,504,mo).
correct_edge_label(85,13,hd).
correct_edge_label(85,502,ng).
correct_edge_label(86,4,hd).
correct_edge_label(86,500,ng).
correct_edge_label(157,7,hd).
correct_edge_label(195,7,hd).
correct_edge_label(232,4,ng).
correct_edge_label(310,501,ng).
correct_edge_label(320,502,mo).
correct_edge_label(343,3,nk).
correct_edge_label(364,5,ng).
correct_edge_label(364,6,hd).
correct_edge_label(391,3,ng).
correct_edge_label(391,4,hd).
correct_edge_label(405,4,ng).
correct_edge_label(405,5,hd).
correct_edge_label(440,10,ng).
correct_edge_label(440,11,hd).
correct_edge_label(457,503,ng).
correct_edge_label(459,505,ng).
correct_edge_label(511,502,ng).
correct_edge_label(515,500,ng).

correct_attachment(85,12,504).
correct_attachment(143,17,507).
correct_attachment(143,502,507).
correct_attachment(143,513,507).
correct_attachment(343,4,506).
correct_attachment(391,3,502).
correct_attachment(445,508,510).
correct_attachment(445,4,510).

unnecessary_node(143,506).
unnecessary_node(343,507).

additional_node(node(445,510,504,'$phrase','$phrase',oc,vp,[])).

correct_surf(401,13,'...').

























