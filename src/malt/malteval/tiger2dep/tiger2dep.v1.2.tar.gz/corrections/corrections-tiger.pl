additional_node(node(607,513,504,'$phrase','$phrase',nk,ap,[])).
additional_node(secondary(778,3,505,hd)).
additional_node(secondary(822,19,504,hd)).
additional_node(secondary(978,18,505,hd)).
additional_node(secondary(1398,15,505,hd)).
additional_node(secondary(1929,14,506,hd)).
additional_node(secondary(3096,4,504,hd)).
additional_node(secondary(3096,11,503,svp)).
additional_node(secondary(3267,500,506,mo)).
additional_node(secondary(3267,3,506,hd)).
additional_node(secondary(3289,3,511,hd)).
additional_node(secondary(3625,4,505,nk)).
additional_node(secondary(3817,500,507,sb)).
additional_node(secondary(3817,4,507,hd)).
additional_node(node(5011,506,501,'$phrase','$phrase',nk,ap,[])).
additional_node(secondary(5240,501,538,mo)).
additional_node(secondary(5240,501,539,mo)).
additional_node(secondary(5240,501,540,mo)).
additional_node(node(6152,522,505,'$phrase','$phrase',mo,pp,[])).
additional_node(node(7069,521,505,'$phrase','$phrase',nk,np,[])).
additional_node(node(7289,516,505,'$phrase','$phrase',ams,np,[])).
additional_node(node(8747,517,507,'$phrase','$phrase',oc,vp,[])).
additional_node(node(11314,506,501,'$phrase','$phrase',nk,ap,[])).
additional_node(node(11542,506,501,'$phrase','$phrase',nk,ap,[])).
additional_node(node(14230,510,507,'$phrase','$phrase',sb,np,[])).
additional_node(node(14620,508,505,'$phrase','$phrase',nk,ap,[])).
additional_node(secondary(16562,6,507,hd)).
additional_node(secondary(17200,508,509,oa)).
additional_node(node(18630,517,514,'$phrase','$phrase',nk,ap,[])).
additional_node(node(21788,515,502,'$phrase','$phrase',nk,np,[])).
additional_node(node(21881,524,504,'$phrase','$phrase',da,np,[])).
additional_node(node(22150,519,507,'$phrase','$phrase',nk,np,[])).
additional_node(node(23061,520,505,'$phrase','$phrase',nk,np,[])).
additional_node(node(23257,509,507,'$phrase','$phrase',oc,vp,[])).
additional_node(node(23488,516,506,'$phrase','$phrase',ams,np,[])).
additional_node(node(24476,510,503,'$phrase','$phrase',ams,np,[])).
additional_node(node(31496,509,505,'$phrase','$phrase',nk,np,[])).
additional_node(node(31517,509,501,'$phrase','$phrase',nk,np,[])).
additional_node(node(31737,513,502,'$phrase','$phrase',nk,np,[])).
additional_node(node(32044,506,500,'$phrase','$phrase',nk,np,[])).
additional_node(node(32745,533,500,'$phrase','$phrase',nk,np,[])).
additional_node(node(32904,524,520,'$phrase','$phrase',nk,np,[])).
additional_node(node(32991,517,506,'$phrase','$phrase',nk,np,[])).
additional_node(node(33156,521,505,'$phrase','$phrase',nk,np,[])).
additional_node(node(33224,518,504,'$phrase','$phrase',nk,np,[])).
additional_node(node(33500,513,-1,'$phrase','$phrase',--,s,[])).
additional_node(node(33741,506,500,'$phrase','$phrase',nk,np,[])).
additional_node(node(33837,504,500,'$phrase','$phrase',nk,np,[])).
additional_node(node(34684,513,503,'$phrase','$phrase',nk,ap,[])).
additional_node(node(35262,508,501,'$phrase','$phrase',nk,ap,[])).
additional_node(node(36832,514,513,'$phrase','$phrase',mo,cpp,[])).
additional_node(node(37059,511,506,'$phrase','$phrase',nk,np,[])).
additional_node(secondary(38664,19,504,hd)).
additional_node(node(40997,503,-1,'$phrase','$phrase',--,s,[])).
additional_node(node(41143,507,501,'$phrase','$phrase',nk,ap,[])).
additional_node(secondary(41806,22,506,hd)).
additional_node(secondary(41806,22,507,hd)).
additional_node(secondary(41806,22,508,hd)).
additional_node(node(41816,509,503,'$phrase','$phrase',nk,ap,[])).
additional_node(node(42194,504,500,'$phrase','$phrase',nk,ap,[])).
additional_node(node(42218,507,502,'$phrase','$phrase',nk,ap,[])).
additional_node(node(42398,505,502,'$phrase','$phrase',nk,ap,[])).
additional_node(node(42947,504,501,'$phrase','$phrase',nk,ap,[])).
additional_node(node(42947,505,504,'$phrase','$phrase',mo,np,[])).
additional_node(node(43139,507,504,'$phrase','$phrase',nk,ap,[])).
additional_node(node(43355,510,505,'$phrase','$phrase',ams,np,[])).
additional_node(secondary(43476,10,509,hd)).
additional_node(node(45109,512,501,'$phrase','$phrase',nk,ap,[])).
additional_node(node(46501,517,515,'$phrase','$phrase',nk,np,[])).
additional_node(node(46556,520,503,'$phrase','$phrase',nk,np,[])).
additional_node(node(46564,513,504,'$phrase','$phrase',nk,np,[])).
additional_node(node(46599,517,500,'$phrase','$phrase',nk,np,[])).
additional_node(node(47011,509,501,'$phrase','$phrase',nk,np,[])).

% order is important:
additional_node(node(47852,504,-1,'$phrase','$phrase',--,s,[])).
additional_node(node(47852,503,504,'$phrase','$phrase',oc,vp,[])).
additional_node(node(47852,500,503,'$phrase','$phrase',da,np,[])).
additional_node(node(47852,502,503,'$phrase','$phrase',oa,np,[])).
additional_node(node(47852,501,502,'$phrase','$phrase',mo,pp,[])).

additional_node(node(48818,506,500,'$phrase','$phrase',nk,ap,[])).
additional_node(node(48968,515,502,'$phrase','$phrase',nk,np,[])).
additional_node(secondary(49406,2,505,sb)).


correct_attachment(603,510,513).
correct_attachment(607,23,513).
correct_attachment(607,24,513).
correct_attachment(933,54,516).
correct_attachment(933,507,516).
correct_attachment(1195,513,517).
correct_attachment(1435,18,504).
correct_attachment(1435,19,504).
correct_attachment(3084,6,503).
correct_attachment(4086,513,507).
correct_attachment(4171,13,505).
correct_attachment(4171,14,505).
correct_attachment(4191,10,505).
correct_attachment(4191,14,504).
correct_attachment(4942,505,507).
correct_attachment(5011,6,506).
correct_attachment(5011,7,506).
correct_attachment(5240,129,525).
correct_attachment(5240,130,-1).
correct_attachment(5539,4,503).
correct_attachment(5552,33,507).
correct_attachment(5552,34,507).
correct_attachment(5678,32,510).
correct_attachment(5762,4,500).
correct_attachment(5871,14,504).
correct_attachment(5871,15,504).
correct_attachment(5871,16,504).
correct_attachment(6152,26,522).
correct_attachment(6152,27,522).
correct_attachment(7069,30,521).
correct_attachment(7069,31,521).
correct_attachment(7289,34,516).
correct_attachment(7289,35,516).
correct_attachment(8199,9,514).
correct_attachment(8219,7,505).
correct_attachment(8219,501,505).
correct_attachment(8747,12,517).
correct_attachment(8747,501,517).
correct_attachment(8963,6,502).
correct_attachment(8963,7,502).
correct_attachment(9185,12,507).
correct_attachment(9185,13,507).
correct_attachment(9195,503,512).
correct_attachment(9261,503,505).
correct_attachment(9261,505,510).
correct_attachment(9577,506,508).
correct_attachment(9306,505,514).
correct_attachment(9397,8,513).
correct_attachment(9397,501,513).
correct_attachment(11314,10,506).
correct_attachment(11314,11,506).
correct_attachment(11314,12,506).
correct_attachment(11542,12,506).
correct_attachment(11542,13,506).
correct_attachment(12325,4,505).
correct_attachment(12325,5,505).
correct_attachment(12761,22,508).
correct_attachment(12761,23,506).
correct_attachment(13018,501,507).
correct_attachment(13125,8,503).
correct_attachment(13513,9,-1).
correct_attachment(13768,12,508).
correct_attachment(13768,13,508).
correct_attachment(13768,19,508).
correct_attachment(13768,20,508).
correct_attachment(13901,501,503).
correct_attachment(13964,1,507).
correct_attachment(14006,506,507).
correct_attachment(14068,2,508).
correct_attachment(14230,9,510).
correct_attachment(14230,506,510).
correct_attachment(14243,508,514).
correct_attachment(14243,30,512).
correct_attachment(14399,507,511).
correct_attachment(14509,505,509).
correct_attachment(14620,2,508).
correct_attachment(14620,3,508).
correct_attachment(14817,14,518).
correct_attachment(14849,12,504).
correct_attachment(15789,14,-1).
correct_attachment(15789,15,-1).
correct_attachment(15789,16,-1).
correct_attachment(16552,508,515).
correct_attachment(16552,511,515).
correct_attachment(16787,37,513).
correct_attachment(17002,26,509).
correct_attachment(17002,27,509).
correct_attachment(18268,2,505).
correct_attachment(18268,503,505).
correct_attachment(18517,3,501).
correct_attachment(18517,4,501).
correct_attachment(18630,20,517).
correct_attachment(18630,21,517).
correct_attachment(18792,8,505).
correct_attachment(18792,501,506).
correct_attachment(18922,1,504).
correct_attachment(19171,10,501).
correct_attachment(19171,12,501).
correct_attachment(20122,4,501).
correct_attachment(21289,6,503).
correct_attachment(21289,501,503).
correct_attachment(21788,18,515).
correct_attachment(21788,19,515).
correct_attachment(21818,11,501).
correct_attachment(21881,26,524).
correct_attachment(21881,27,524).
correct_attachment(22069,501,514).
correct_attachment(22069,38,511).
correct_attachment(22150,33,519).
correct_attachment(22150,34,519).
correct_attachment(22247,18,503).
correct_attachment(22322,9,505).
correct_attachment(22322,11,502).
correct_attachment(22476,11,502).
correct_attachment(22498,24,507).
correct_attachment(22816,504,507).
correct_attachment(23061,34,520).
correct_attachment(23061,35,520).
correct_attachment(23257,12,509).
correct_attachment(23257,502,509).
correct_attachment(23274,15,505).
correct_attachment(23274,16,505).
correct_attachment(23300,27,509).
correct_attachment(23300,31,511).
correct_attachment(23300,33,506).
correct_attachment(23300,510,514).
correct_attachment(23300,513,510).
correct_attachment(23488,2,516).
correct_attachment(23488,3,516).
correct_attachment(23728,14,507).
correct_attachment(23728,15,507).
correct_attachment(24458,502,505).
correct_attachment(24476,16,510).
correct_attachment(24476,17,510).
correct_attachment(26710,29,512).
correct_attachment(26710,36,511).
correct_attachment(26710,511,513).
correct_attachment(26710,512,511).
correct_attachment(28622,521,523).
correct_attachment(28955,501,507).
correct_attachment(29897,503,505).
correct_attachment(29897,505,507).
correct_attachment(31496,13,509).
correct_attachment(31496,14,509).
correct_attachment(31517,8,509).
correct_attachment(31517,9,509).
correct_attachment(31737,32,513).
correct_attachment(31737,33,513).
correct_attachment(32044,3,506).
correct_attachment(32044,4,506).
correct_attachment(32745,1,533).
correct_attachment(32745,2,533).
correct_attachment(32904,34,524).
correct_attachment(32904,35,524).
correct_attachment(32991,24,517).
correct_attachment(32991,25,517).
correct_attachment(33137,5,504).
correct_attachment(33137,501,504).
correct_attachment(33156,43,521).
correct_attachment(33156,44,521).
correct_attachment(33221,16,503).
correct_attachment(33221,17,503).
correct_attachment(33221,21,503).
correct_attachment(33221,508,507).
correct_attachment(33224,38,518).
correct_attachment(33224,39,518).
correct_attachment(33264,3,508).
correct_attachment(33287,10,504).
correct_attachment(33287,12,504).
correct_attachment(33500,18,513).
correct_attachment(33500,19,513).
correct_attachment(33500,511,513).
correct_attachment(33500,512,513).
correct_attachment(33741,1,506).
correct_attachment(33741,2,506).
correct_attachment(33806,10,502).
correct_attachment(33806,11,502).
correct_attachment(33837,7,504).
correct_attachment(33837,8,504).
correct_attachment(34071,504,506).
correct_attachment(34118,29,507).
correct_attachment(34118,30,507).
correct_attachment(34118,33,508).
correct_attachment(34118,34,508).
correct_attachment(34684,15,513).
correct_attachment(34684,16,513).
correct_attachment(34690,1,504).
correct_attachment(34757,9,507).
correct_attachment(34757,10,507).
correct_attachment(35035,129,559).
correct_attachment(35035,130,-1).
correct_attachment(35221,19,522).
correct_attachment(35221,519,522).
correct_attachment(35262,9,508).
correct_attachment(35262,10,508).
correct_attachment(36832,501,514).
correct_attachment(36832,502,514).
correct_attachment(36832,512,514).
correct_attachment(37059,21,511).
correct_attachment(37059,22,511).
correct_attachment(37725,16,506).
correct_attachment(37725,17,506).
correct_attachment(38714,10,503).
correct_attachment(39119,2,502).
correct_attachment(39119,3,502).
correct_attachment(40997,4,503).
correct_attachment(40997,5,503).
correct_attachment(40997,6,503).
correct_attachment(40997,7,503).
correct_attachment(40997,500,503).
correct_attachment(40997,502,503).
correct_attachment(41143,12,507).
correct_attachment(41143,13,507).
correct_attachment(41816,18,509).
correct_attachment(41816,19,509).
correct_attachment(41816,20,509).
correct_attachment(42194,3,504).
correct_attachment(42194,4,504).
correct_attachment(42194,5,504).
correct_attachment(42218,7,507).
correct_attachment(42218,8,507).
correct_attachment(42218,9,507).
correct_attachment(42398,8,505).
correct_attachment(42398,9,505).
correct_attachment(42398,10,505).
correct_attachment(42947,7,505).
correct_attachment(42947,8,505).
correct_attachment(42947,9,504).
correct_attachment(43139,8,507).
correct_attachment(43139,9,507).
correct_attachment(43139,10,507).
correct_attachment(43355,17,510).
correct_attachment(43355,18,510).
correct_attachment(44563,503,502).
correct_attachment(45002,6,502).
correct_attachment(45002,7,502).
correct_attachment(45109,10,512).
correct_attachment(45109,11,512).
correct_attachment(45109,12,512).
correct_attachment(46178,507,506).
correct_attachment(46234,129,543).
correct_attachment(46234,130,537).
correct_attachment(46234,132,-1).
correct_attachment(46234,134,-1).
correct_attachment(46234,136,-1).
correct_attachment(46241,502,510).
correct_attachment(46501,13,517).
correct_attachment(46501,14,517).
correct_attachment(46556,18,520).
correct_attachment(46556,19,520).
correct_attachment(46564,19,513).
correct_attachment(46564,20,513).
correct_attachment(46599,1,517).
correct_attachment(46599,2,517).
correct_attachment(47011,20,509).
correct_attachment(47011,21,509).
correct_attachment(47852,1,504).
correct_attachment(47852,2,500).
correct_attachment(47852,3,500).
correct_attachment(47852,4,504).
correct_attachment(47852,5,504).
correct_attachment(47852,6,502).
correct_attachment(47852,7,502).
correct_attachment(47852,8,501).
correct_attachment(47852,9,501).
correct_attachment(47852,10,503).
correct_attachment(48017,19,508).
correct_attachment(48818,3,506).
correct_attachment(48818,4,506).
correct_attachment(48968,16,515).
correct_attachment(48968,17,515).
correct_attachment(48997,17,505).
correct_attachment(48997,18,505).
correct_attachment(49370,502,505).
correct_attachment(49406,10,505).
correct_attachment(49408,13,506).
correct_attachment(49408,14,506).
correct_attachment(49408,15,506).
correct_attachment(49408,16,506).
correct_attachment(49459,8,509).
correct_attachment(49459,509,511).
correct_attachment(49795,21,507).
correct_attachment(49795,22,507).
correct_attachment(50224,129,547).
correct_attachment(50224,130,547).
correct_attachment(50224,131,-1).
correct_attachment(50224,132,532).
correct_attachment(50224,139,-1).
correct_attachment(50224,140,533).
correct_attachment(50224,143,-1).
correct_attachment(50227,19,504).
correct_attachment(50404,6,502).
correct_attachment(50404,7,502).


correct_edge_label(22,501,app).
correct_edge_label(88,513,par).
correct_edge_label(119,11,mo).
correct_edge_label(444,12,cm).
correct_edge_label(452,11,hd).
correct_edge_label(496,1,cm).
correct_edge_label(531,503,nk).
correct_edge_label(536,29,svp).
correct_edge_label(603,510,sb).
correct_edge_label(607,23,mo).
correct_edge_label(607,24,hd).
correct_edge_label(868,2,cp).
correct_edge_label(933,53,ac).
correct_edge_label(933,516,mnr).
correct_edge_label(1102,511,mo).
correct_edge_label(1192,5,nk).
correct_edge_label(1435,17,ac).
correct_edge_label(1706,500,ams).
correct_edge_label(1885,8,ph).
correct_edge_label(1885,505,op).
correct_edge_label(2013,10,mo).
correct_edge_label(2022,504,mo).
correct_edge_label(2109,12,mo).
correct_edge_label(2109,13,hd).
correct_edge_label(2152,502,oc).
correct_edge_label(2170,508,oc).
correct_edge_label(2398,38,hd).
correct_edge_label(2424,9,mo).
correct_edge_label(2587,502,oc).
correct_edge_label(2609,500,ams).
correct_edge_label(2675,6,oa).
correct_edge_label(2789,14,svp).
correct_edge_label(2943,12,mo).
correct_edge_label(3026,11,mo).
correct_edge_label(3063,17,mo).
correct_edge_label(3260,506,mo).
correct_edge_label(3391,503,ag).
correct_edge_label(3613,10,nk).
correct_edge_label(3685,21,oc).
correct_edge_label(3936,21,oa).
correct_edge_label(3944,5,cm).
correct_edge_label(4030,10,oc).
correct_edge_label(4086,6,nk).
correct_edge_label(4086,513,cj).
correct_edge_label(4112,1,pm).
correct_edge_label(4191,10,hd).
correct_edge_label(4191,14,cm).
correct_edge_label(4191,504,cc).
correct_edge_label(4290,3,hd).
correct_edge_label(4468,6,cm).
correct_edge_label(4468,502,cc).
correct_edge_label(4605,12,og).
correct_edge_label(4664,501,ams).
correct_edge_label(4699,500,nk).
correct_edge_label(4733,13,oa).
correct_edge_label(5011,6,mo).
correct_edge_label(5011,7,hd).
correct_edge_label(5032,12,mo).
correct_edge_label(5056,20,sb).
correct_edge_label(5075,18,hd).
correct_edge_label(5075,19,mo).
correct_edge_label(5075,503,ng).
correct_edge_label(5088,31,avc).
correct_edge_label(5088,32,avc).
correct_edge_label(5115,505,sbp).
correct_edge_label(5119,1,op).
correct_edge_label(5206,505,hd).
correct_edge_label(5387,7,oa).
correct_edge_label(5387,8,sb).
correct_edge_label(5495,504,ams).
correct_edge_label(5515,20,pm).
correct_edge_label(5515,21,hd).
correct_edge_label(5517,502,ams).
correct_edge_label(5539,4,nk).
correct_edge_label(5552,31,uc).
correct_edge_label(5552,33,uc).
correct_edge_label(5552,34,uc).
correct_edge_label(5592,6,nk).
correct_edge_label(5592,7,nk).
correct_edge_label(5678,32,da).
correct_edge_label(5678,508,og).
correct_edge_label(5762,4,mo).
correct_edge_label(5804,2,nk).
correct_edge_label(5827,8,hd).
correct_edge_label(5827,9,mo).
correct_edge_label(5857,23,avc).
correct_edge_label(5857,24,avc).
correct_edge_label(5872,5,nk).
correct_edge_label(5900,504,da).
correct_edge_label(5950,15,hd).
correct_edge_label(6048,506,nk).
correct_edge_label(6152,25,hd).
correct_edge_label(6236,501,mo).
correct_edge_label(6587,501,ams).
correct_edge_label(6903,19,nk).
correct_edge_label(7047,17,svp).
correct_edge_label(7058,61,ac).
correct_edge_label(7058,513,mnr).
correct_edge_label(7289,36,hd).
correct_edge_label(7429,14,svp).
correct_edge_label(7554,503,ng).
correct_edge_label(7891,2,cp).
correct_edge_label(8067,1,ams).
correct_edge_label(8067,2,hd).
correct_edge_label(8079,21,pnc).
correct_edge_label(8079,22,pnc).
correct_edge_label(8199,9,cd).
correct_edge_label(8345,6,nk).
correct_edge_label(8358,32,nk).
correct_edge_label(8408,15,ac).
correct_edge_label(8408,503,nk).
correct_edge_label(8712,501,ag).
correct_edge_label(8837,1,ju).
correct_edge_label(8981,15,hd).
correct_edge_label(9134,508,cc).
correct_edge_label(9195,503,pd).
correct_edge_label(9261,505,op).
correct_edge_label(9306,505,cj).
correct_edge_label(9397,7,ac).
correct_edge_label(9403,505,ams).
correct_edge_label(9577,506,pd).
correct_edge_label(9757,11,hd).
correct_edge_label(9757,501,ng).
correct_edge_label(10038,7,cm).
correct_edge_label(10053,1,ac).
correct_edge_label(10320,21,cm).
correct_edge_label(10350,20,oa).
correct_edge_label(10445,502,ams).
correct_edge_label(10565,11,oa).
correct_edge_label(11196,517,pg).
correct_edge_label(11230,13,ac).
correct_edge_label(11230,14,nk).
correct_edge_label(11307,509,cc).
correct_edge_label(11314,10,mo).
correct_edge_label(11314,11,mo).
correct_edge_label(11314,12,hd).
correct_edge_label(11315,5,ac).
correct_edge_label(11423,8,hd).
correct_edge_label(11423,9,mo).
correct_edge_label(11450,17,hd).
correct_edge_label(11450,18,mo).
correct_edge_label(11458,15,hd).
correct_edge_label(11458,16,mo).
correct_edge_label(11542,12,mo).
correct_edge_label(11542,13,hd).
correct_edge_label(11571,4,sb).
correct_edge_label(11575,14,mo).
correct_edge_label(11608,509,oc).
correct_edge_label(11999,500,ams).
correct_edge_label(12304,24,oa).
correct_edge_label(12325,5,nk).
correct_edge_label(12583,3,oa).
correct_edge_label(12669,16,ac).
correct_edge_label(12683,501,nk).
correct_edge_label(12691,505,oc).
correct_edge_label(12761,22,sb).
correct_edge_label(12761,23,oa).
correct_edge_label(12924,2,mo).
correct_edge_label(12924,3,hd).
correct_edge_label(12993,503,ams).
correct_edge_label(13018,7,nk).
correct_edge_label(13018,501,mo).
correct_edge_label(13089,3,da).
correct_edge_label(13125,8,ac).
correct_edge_label(13178,24,ep).
correct_edge_label(13307,503,mo).
correct_edge_label(13392,14,mo).
correct_edge_label(13473,42,pm).
correct_edge_label(13473,43,hd).
correct_edge_label(13492,505,mo).
correct_edge_label(13531,7,pm).
correct_edge_label(13619,504,op).
correct_edge_label(13635,16,pm).
correct_edge_label(13635,17,hd).
correct_edge_label(13700,9,mo).
correct_edge_label(13717,503,mo).
correct_edge_label(13768,13,cp).
correct_edge_label(13901,501,mo).
correct_edge_label(13901,503,pd).
correct_edge_label(13964,1,cp).
correct_edge_label(13992,512,hd).
correct_edge_label(14006,506,mo).
correct_edge_label(14015,9,da).
correct_edge_label(14042,500,cc).
correct_edge_label(14048,31,par).
correct_edge_label(14056,505,ng).
correct_edge_label(14088,4,oa2).
correct_edge_label(14159,9,mo).
correct_edge_label(14159,501,ng).
correct_edge_label(14208,7,ac).
correct_edge_label(14226,8,mo).
correct_edge_label(14230,9,ph).
correct_edge_label(14230,506,re).
correct_edge_label(14243,23,mo).
correct_edge_label(14243,514,par).
correct_edge_label(14243,508,mo).
correct_edge_label(14243,512,sb).
correct_edge_label(14249,28,mo).
correct_edge_label(14257,501,par).
correct_edge_label(14297,13,nk).
correct_edge_label(14297,501,mo).
correct_edge_label(14386,11,pm).
correct_edge_label(14386,12,hd).
correct_edge_label(14424,513,mo).
correct_edge_label(14480,2,nk).
correct_edge_label(14496,508,cc).
correct_edge_label(14597,6,pm).
correct_edge_label(14597,7,hd).
correct_edge_label(14600,1,sb).
correct_edge_label(14620,2,mo).
correct_edge_label(14620,3,hd).
correct_edge_label(14635,19,ac).
correct_edge_label(14635,20,nk).
correct_edge_label(14671,11,mo).
correct_edge_label(14775,16,nk).
correct_edge_label(14796,503,ng).
correct_edge_label(14834,18,mo).
correct_edge_label(14841,2,nk).
correct_edge_label(14841,500,mo).
correct_edge_label(14911,502,mo).
correct_edge_label(14983,503,pd).
correct_edge_label(15107,3,svp).
correct_edge_label(15192,4,oa).
correct_edge_label(15193,3,oa).
correct_edge_label(15406,21,mo).
correct_edge_label(15625,2,nk).
correct_edge_label(15682,36,cm).
correct_edge_label(15789,14,--).
correct_edge_label(15789,15,--).
correct_edge_label(15789,16,--).
correct_edge_label(16031,5,ac).
correct_edge_label(16031,6,nk).
correct_edge_label(16031,501,pd).
correct_edge_label(16167,1,nk).
correct_edge_label(16167,500,nk).
correct_edge_label(16450,9,svp).
correct_edge_label(16552,38,ac).
correct_edge_label(16552,508,ag).
correct_edge_label(16552,511,mnr).
correct_edge_label(16684,27,hd).
correct_edge_label(16853,8,nk).
correct_edge_label(16937,9,ams).
correct_edge_label(17002,24,uc).
correct_edge_label(17002,26,uc).
correct_edge_label(17002,27,uc).
correct_edge_label(17321,503,ams).
correct_edge_label(17776,503,ams).
correct_edge_label(17842,5,hd).
correct_edge_label(17895,1,cm).
correct_edge_label(17915,37,ac).
correct_edge_label(17927,21,avc).
correct_edge_label(17927,22,avc).
correct_edge_label(18003,500,ams).
correct_edge_label(18025,18,svp).
correct_edge_label(18029,1,sb).
correct_edge_label(18062,11,oa).
correct_edge_label(18076,504,pg).
correct_edge_label(18146,4,cm).
correct_edge_label(18146,508,cc).
correct_edge_label(18216,504,oc).
correct_edge_label(18225,28,avc).
correct_edge_label(18225,29,avc).
correct_edge_label(18268,2,nk).
correct_edge_label(18321,2,mo).
correct_edge_label(18321,3,hd).
correct_edge_label(18324,8,pm).
correct_edge_label(18517,4,ng).
correct_edge_label(18540,5,cm).
correct_edge_label(18540,509,cc).
correct_edge_label(18630,20,mo).
correct_edge_label(18630,21,hd).
correct_edge_label(18792,8,ac).
correct_edge_label(18811,4,pm).
correct_edge_label(19009,10,ac).
correct_edge_label(19011,4,ng).
correct_edge_label(19011,5,hd).
correct_edge_label(19011,501,mo).
correct_edge_label(19046,503,ams).
correct_edge_label(19070,23,pm).
correct_edge_label(19157,9,ng).
correct_edge_label(19157,10,hd).
correct_edge_label(19157,501,mo).
correct_edge_label(19171,10,cj).
correct_edge_label(19171,12,cj).
correct_edge_label(19183,11,svp).
correct_edge_label(19311,25,ng).
correct_edge_label(19311,26,hd).
correct_edge_label(19311,504,mo).
correct_edge_label(19867,5,ng).
correct_edge_label(19867,6,hd).
correct_edge_label(19867,500,mo).
correct_edge_label(19904,7,ng).
correct_edge_label(19904,8,hd).
correct_edge_label(19904,501,mo).
correct_edge_label(20016,30,hd).
correct_edge_label(20032,502,cc).
correct_edge_label(20052,22,ng).
correct_edge_label(20052,23,hd).
correct_edge_label(20052,505,mo).
correct_edge_label(20122,4,hd).
correct_edge_label(20204,23,hd).
correct_edge_label(20305,17,pm).
correct_edge_label(20313,14,ng).
correct_edge_label(20313,15,hd).
correct_edge_label(20313,502,mo).
correct_edge_label(20460,10,ac).
correct_edge_label(20460,502,mnr).
correct_edge_label(20557,501,ng).
correct_edge_label(21020,11,da).
correct_edge_label(21289,501,mnr).
correct_edge_label(21676,5,ac).
correct_edge_label(21676,511,mnr).
correct_edge_label(21798,506,cc).
correct_edge_label(21818,501,ng).
correct_edge_label(21881,25,hd).
correct_edge_label(21989,31,pm).
correct_edge_label(21991,12,pm).
correct_edge_label(22069,6,ng).
correct_edge_label(22069,7,hd).
correct_edge_label(22069,38,mo).
correct_edge_label(22069,501,mo).
correct_edge_label(22072,24,ng).
correct_edge_label(22072,25,hd).
correct_edge_label(22072,506,cc).
correct_edge_label(22103,22,mo).
correct_edge_label(22120,1,mo).
correct_edge_label(22163,502,hd).
correct_edge_label(22172,7,mo).
correct_edge_label(22190,7,cm). % maybe, the entire structure is wrong here
correct_edge_label(22277,2,da).
correct_edge_label(22247,19,nk).
correct_edge_label(22247,20,nk).
correct_edge_label(22309,18,mo).
correct_edge_label(22322,9,cd).
correct_edge_label(22322,10,mo).
correct_edge_label(22322,11,nk).
correct_edge_label(22322,502,cj).
correct_edge_label(22402,2,nk).
correct_edge_label(22412,501,ng).
correct_edge_label(22471,23,ac).
correct_edge_label(22476,10,mo).
correct_edge_label(22476,12,hd).
correct_edge_label(22494,17,cj).
correct_edge_label(22494,18,cd).
correct_edge_label(22494,19,cj).
correct_edge_label(22498,24,hd).
correct_edge_label(22498,505,mo).
correct_edge_label(22529,1,pm).
correct_edge_label(22643,503,mo).
correct_edge_label(22675,13,par).
correct_edge_label(22735,29,nk).
correct_edge_label(22759,12,oa).
correct_edge_label(22281,500,oa).
correct_edge_label(22816,6,hd).
correct_edge_label(22816,507,pd).
correct_edge_label(22976,14,hd).
correct_edge_label(22977,4,hd).
correct_edge_label(23041,16,mo).
correct_edge_label(23048,33,ac).
correct_edge_label(23048,507,mo).
correct_edge_label(23050,14,pm).
correct_edge_label(23088,12,ac).
correct_edge_label(23088,13,nk).
correct_edge_label(23088,502,mo).
correct_edge_label(23088,513,hd).
correct_edge_label(23103,500,oc).
correct_edge_label(23106,28,nk).
correct_edge_label(23107,34,oa).
correct_edge_label(23135,502,hd).
correct_edge_label(23206,23,ac).
correct_edge_label(23206,24,nk).
correct_edge_label(23217,15,ac).
correct_edge_label(23244,6,mo).
correct_edge_label(23257,502,hd).
correct_edge_label(23293,23,mo).
correct_edge_label(23293,503,cp).
correct_edge_label(23300,27,mo).
correct_edge_label(23300,31,cd).
correct_edge_label(23300,32,mo).
correct_edge_label(23300,33,hd).
correct_edge_label(23300,503,cj).
correct_edge_label(23300,506,cj).
correct_edge_label(23300,510,pd).
correct_edge_label(23300,513,cj).
correct_edge_label(23333,24,mo).
correct_edge_label(23333,32,hd). % here, we lose information about negation
correct_edge_label(23334,18,mo).
correct_edge_label(23335,11,mo).
correct_edge_label(23488,4,hd).
correct_edge_label(23494,6,ac).
correct_edge_label(23494,7,ac).
correct_edge_label(23660,1,ju).
correct_edge_label(23660,2,mo).
correct_edge_label(23680,20,oa).
correct_edge_label(23680,504,mo).
correct_edge_label(23705,19,svp).
correct_edge_label(23728,15,cp).
correct_edge_label(23799,509,pg).
correct_edge_label(23816,1,ph).
correct_edge_label(23921,503,mo).
correct_edge_label(24066,14,ng).
correct_edge_label(24068,1,svp).
correct_edge_label(24458,502,mo).
correct_edge_label(24476,18,hd).
correct_edge_label(24527,3,ac).
correct_edge_label(25003,502,og).
correct_edge_label(25328,23,nk).
correct_edge_label(26160,513,pg).
correct_edge_label(26198,23,da).
correct_edge_label(26220,501,mo).
correct_edge_label(26555,503,oc).
correct_edge_label(26638,7,svp).
correct_edge_label(26710,29,cj).
correct_edge_label(26710,35,hd).
correct_edge_label(26710,511,rc).
correct_edge_label(26710,512,pd).
correct_edge_label(26952,19,hd).
correct_edge_label(27054,16,mo).
correct_edge_label(27065,7,nk).
correct_edge_label(27199,7,pm).
correct_edge_label(27238,503,oc).
correct_edge_label(27253,3,hd).
correct_edge_label(27253,4,da).
correct_edge_label(27253,500,pd).
correct_edge_label(27337,22,pm).
correct_edge_label(27691,500,oa).
correct_edge_label(27702,13,svp).
correct_edge_label(27706,506,op).
correct_edge_label(27709,515,oc).
correct_edge_label(27765,514,oc).
correct_edge_label(27813,504,ams).
correct_edge_label(28312,504,ams).
correct_edge_label(28319,501,ams).
correct_edge_label(28352,503,ams).
correct_edge_label(28561,22,mo).
correct_edge_label(28633,8,pm).
correct_edge_label(28780,11,sb).
correct_edge_label(28793,10,mo).
correct_edge_label(28794,39,da).
correct_edge_label(28909,501,oc).
correct_edge_label(28995,16,mo).
correct_edge_label(29123,2,cm).
correct_edge_label(29123,500,cc).
correct_edge_label(29150,500,ng).
correct_edge_label(29230,6,cm).
correct_edge_label(29230,505,cc).
correct_edge_label(29493,506,oc).
correct_edge_label(29590,12,mo).
correct_edge_label(29622,45,oa2).
correct_edge_label(29693,513,oc).
correct_edge_label(29729,15,svp).
correct_edge_label(29741,1,ph).
correct_edge_label(29771,4,ag).
correct_edge_label(29781,26,mo).
correct_edge_label(29790,17,mo).
correct_edge_label(29917,16,mo).
correct_edge_label(30101,502,ams).
correct_edge_label(30244,4,ac).
correct_edge_label(30401,4,oa).
correct_edge_label(30495,8,mo).
correct_edge_label(30498,3,mo).
correct_edge_label(30498,501,mo).
correct_edge_label(30498,12,mo).
correct_edge_label(30816,10,pm).
correct_edge_label(31637,500,ams).
correct_edge_label(31644,10,da).
correct_edge_label(31753,18,ac).
correct_edge_label(31753,505,mnr).
correct_edge_label(31907,500,da).
correct_edge_label(32091,24,nk).
correct_edge_label(32119,28,svp).
correct_edge_label(32147,508,op).
correct_edge_label(32211,7,mo).
correct_edge_label(32770,4,da).
correct_edge_label(33032,18,oa).
correct_edge_label(33054,11,svp).
correct_edge_label(33168,505,sb).
correct_edge_label(33188,503,ng).
correct_edge_label(33195,14,oa).
correct_edge_label(33220,500,ng).
correct_edge_label(33249,7,oa).
correct_edge_label(33264,1,hd).
correct_edge_label(33264,3,nk).
correct_edge_label(33299,504,mo).
correct_edge_label(33500,18,hd).
correct_edge_label(33500,512,sb).
correct_edge_label(33523,24,svp).
correct_edge_label(33548,20,cm).
correct_edge_label(33597,18,mo).
correct_edge_label(33366,503,oa).
correct_edge_label(33784,12,ac).
correct_edge_label(33806,9,ac).
correct_edge_label(33855,503,mo).
correct_edge_label(34012,24,hd).
correct_edge_label(34012,25,mo).
correct_edge_label(34071,13,hd).
correct_edge_label(34084,16,mo).
correct_edge_label(34084,503,ng).
correct_edge_label(34086,21,oc).
correct_edge_label(34118,507,ams).
correct_edge_label(34330,6,nk).
correct_edge_label(34400,7,ac).
correct_edge_label(34400,501,nk).
correct_edge_label(34400,502,pd).
correct_edge_label(34501,500,nk).
correct_edge_label(34571,502,nk).
correct_edge_label(34677,28,pm).
correct_edge_label(34677,29,hd).
correct_edge_label(34684,15,mo).
correct_edge_label(34684,16,hd).
correct_edge_label(34690,1,cp).
correct_edge_label(34757,9,ng).
correct_edge_label(34788,507,sb).
correct_edge_label(34870,29,hd).
correct_edge_label(35221,19,nk).
correct_edge_label(35221,519,nk).
correct_edge_label(35262,9,mo).
correct_edge_label(35262,10,hd).
correct_edge_label(35466,503,mo).
correct_edge_label(36086,3,ac).
correct_edge_label(36136,503,ams).
correct_edge_label(36183,507,ams).
correct_edge_label(36832,501,cj).
correct_edge_label(36832,502,cj).
correct_edge_label(36832,512,cj).
correct_edge_label(36856,19,svp).
correct_edge_label(36905,20,avc).
correct_edge_label(36905,21,avc).
correct_edge_label(37060,501,sb).
correct_edge_label(37164,500,ams).
correct_edge_label(37222,8,mo).
correct_edge_label(37222,502,hd).
correct_edge_label(37222,503,ng).
correct_edge_label(37227,500,ng).
correct_edge_label(37470,504,ng).
correct_edge_label(37647,504,mo).
correct_edge_label(37668,505,oa).
correct_edge_label(37725,15,ac).
correct_edge_label(38301,507,pg).
correct_edge_label(38458,1,oa).
correct_edge_label(38557,506,ng).
correct_edge_label(39119,3,nk).
correct_edge_label(39911,500,ams).
correct_edge_label(40214,5,da).
correct_edge_label(40513,500,ng).
correct_edge_label(40733,507,oc).
correct_edge_label(40997,4,hd).
correct_edge_label(40997,5,sb).
correct_edge_label(40997,6,mo).
correct_edge_label(40997,7,mo).
correct_edge_label(40997,500,mo).
correct_edge_label(40997,502,oc).
correct_edge_label(41080,18,mo).
correct_edge_label(41143,12,mo).
correct_edge_label(41143,13,hd).
correct_edge_label(41287,16,cm).
correct_edge_label(41288,501,oa).
correct_edge_label(41288,502,mo).
correct_edge_label(41325,15,mo).
correct_edge_label(41494,17,ph).
correct_edge_label(41686,7,nk).
correct_edge_label(41708,7,hd).
correct_edge_label(41716,500,cp).
correct_edge_label(41735,7,oa).
correct_edge_label(41816,18,mo).
correct_edge_label(41816,19,mo).
correct_edge_label(41816,20,hd).
correct_edge_label(42000,503,mo).
correct_edge_label(42107,10,mo).
correct_edge_label(42188,502,mo).
correct_edge_label(42194,3,mo).
correct_edge_label(42194,4,mo).
correct_edge_label(42194,5,hd).
correct_edge_label(42218,9,hd).
correct_edge_label(42398,8,mo).
correct_edge_label(42398,9,mo).
correct_edge_label(42398,10,hd).
correct_edge_label(42569,503,oc).
correct_edge_label(42930,502,ng).
correct_edge_label(42947,9,hd).
correct_edge_label(42999,506,op).
correct_edge_label(43052,17,mo).
correct_edge_label(43139,8,mo).
correct_edge_label(43139,9,mo).
correct_edge_label(43139,10,hd).
correct_edge_label(43139,504,app).
correct_edge_label(43347,13,mo).
correct_edge_label(43355,19,hd).
correct_edge_label(43771,506,oc).
correct_edge_label(43858,503,oc).
correct_edge_label(44115,509,rc).
correct_edge_label(44232,15,mnr).
correct_edge_label(44566,12,cj).
correct_edge_label(44566,14,cj).
correct_edge_label(45002,7,nk).
correct_edge_label(45109,10,mo).
correct_edge_label(45109,11,mo).
correct_edge_label(45109,12,hd).
correct_edge_label(45109,17,mo).
correct_edge_label(45448,502,oc).
correct_edge_label(45681,4,da).
correct_edge_label(45736,4,da).
correct_edge_label(45768,28,mo).
correct_edge_label(45845,500,ams).
correct_edge_label(46001,507,oa).
correct_edge_label(46021,505,oc).
correct_edge_label(46178,507,mo).
correct_edge_label(46241,502,mo).
correct_edge_label(46356,500,mo).
correct_edge_label(46852,12,ag).
correct_edge_label(46879,9,ac).
correct_edge_label(46879,501,mnr).
correct_edge_label(47102,5,nk).
correct_edge_label(47252,13,sb).
correct_edge_label(47252,14,hd).
correct_edge_label(47252,15,mo).
correct_edge_label(47252,16,oc).
correct_edge_label(47252,502,par).
correct_edge_label(47475,502,op).
correct_edge_label(47603,502,oa).
correct_edge_label(47685,500,mo).
correct_edge_label(47836,28,nk).
correct_edge_label(47852,1,ju).
correct_edge_label(47852,2,mo).
correct_edge_label(47852,3,nk).
correct_edge_label(47852,4,hd).
correct_edge_label(47852,5,sb).
correct_edge_label(47852,6,nk).
correct_edge_label(47852,7,nk).
correct_edge_label(47852,8,ac).
correct_edge_label(47852,9,nk).
correct_edge_label(47852,10,hd).
correct_edge_label(47918,505,oa).
correct_edge_label(48017,19,ac).
correct_edge_label(48289,500,ams).
correct_edge_label(48362,21,oa).
correct_edge_label(48421,501,ng).
correct_edge_label(48502,502,ng).
correct_edge_label(48522,7,mo).
correct_edge_label(48522,12,mo).
correct_edge_label(48530,8,da).
correct_edge_label(48546,502,ng).
correct_edge_label(48557,14,ng).
correct_edge_label(48632,506,cc).
correct_edge_label(48642,18,hd).
correct_edge_label(48642,19,mo).
correct_edge_label(48663,501,ams).
correct_edge_label(48791,21,oa).
correct_edge_label(48818,4,hd).
correct_edge_label(49022,62,nk).
correct_edge_label(49092,1,nk).
correct_edge_label(49092,500,nk).
correct_edge_label(49099,501,ng).
correct_edge_label(49170,500,nk).
correct_edge_label(49170,503,nk).
correct_edge_label(49232,502,hd).
correct_edge_label(49373,1,nk).
correct_edge_label(49373,500,mnr).
correct_edge_label(49373,501,nk).
correct_edge_label(49373,6,nk).
correct_edge_label(49406,10,mo).
correct_edge_label(49408,17,mnr).
correct_edge_label(49409,37,hd).
correct_edge_label(49428,501,nk).
correct_edge_label(49428,502,nk).
correct_edge_label(49459,8,mo).
correct_edge_label(49517,11,svp).
correct_edge_label(49603,1,nk).
correct_edge_label(49603,500,nk).
correct_edge_label(49605,3,da).
correct_edge_label(49740,14,nk).
correct_edge_label(49795,20,ac).
correct_edge_label(49878,1,nk).
correct_edge_label(49878,500,nk).
correct_edge_label(50049,1,nk).
correct_edge_label(50049,5,nk).
correct_edge_label(50049,500,nk).
correct_edge_label(50049,501,nk).
correct_edge_label(50156,510,ag).
correct_edge_label(50180,1,nk).
correct_edge_label(50180,5,nk).
correct_edge_label(50180,500,nk).
correct_edge_label(50304,11,ng).
correct_edge_label(50304,12,hd).
correct_edge_label(50366,5,mo).
correct_edge_label(50366,8,mo).
correct_edge_label(50404,7,oa).
correct_edge_label(50236,23,pm).






correct_surf(33877,1,'``').

correct_lemma(3052,23,wenig).
correct_lemma(4978,4,'Recht').
correct_lemma(9403,22,wenig).
correct_lemma(9769,16,wenig).
correct_lemma(10350,20,'Recht').
correct_lemma(10565,11,'Recht').
correct_lemma(12304,24,'Recht').
correct_lemma(12583,3,'Recht').
correct_lemma(15192,4,'Recht').
correct_lemma(15193,3,'Recht').
correct_lemma(19985,4,'Recht').
correct_lemma(29492,26,'Recht').
correct_lemma(29627,41,'m�gen').
correct_lemma(29839,25,'Recht').
correct_lemma(33249,7,'Recht').
correct_lemma(33653,16,'Recht').
correct_lemma(39031,15,'Recht').
correct_lemma(42999,1,absehen).
correct_lemma(45640,11,'Recht').
correct_lemma(46158,23,'Recht').
correct_lemma(48362,21,'Recht').
correct_lemma(48794,3,lassen).
correct_lemma(50404,7,'Recht').

correct_lemma(4670,30,'sp�t').
correct_lemma(5504,53,'sp�t').
correct_lemma(9186,7,'sp�t').
correct_lemma(14994,13,'sp�t').
correct_lemma(23032,31,'sp�t').
correct_lemma(30307,8,'sp�t').
correct_lemma(30315,1,'sp�t').
correct_lemma(32534,31,'sp�t').
correct_lemma(34008,10,'sp�t').
correct_lemma(36818,29,'sp�t').
correct_lemma(42088,1,'sp�t').
correct_lemma(46416,28,'sp�t').
correct_lemma(46708,1,'sp�t').
correct_lemma(48425,15,'sp�t').
correct_lemma(48431,19,'sp�t').
correct_lemma(48433,4,'sp�t').
correct_lemma(48450,7,'sp�t').
correct_lemma(48560,4,'sp�t').
correct_lemma(48788,5,'sp�t').
correct_lemma(49010,7,'sp�t').
correct_lemma(49532,25,'sp�t').



correct_morph(155,13,[case-acc,number-sg,gender-neut]).
correct_morph(398,1,[case-nom,number-sg,gender-masc]).
%correct_morph(529,4,[case-gen,number-sg,gender-neut]). % Tippfehler
correct_morph(538,13,[case-gen,number-pl,gender-fem,degree-pos]).
correct_morph(538,14,[case-gen,number-pl,gender-fem]).
correct_morph(565,9,[case-gen,number-sg,gender-masc]).
correct_morph(618,5,[case-acc,number-sg,gender-masc]).
correct_morph(640,17,[case-gen,number-pl,gender-masc]).
correct_morph(643,3,[case-gen,number-pl,gender-masc]).
correct_morph(671,6,[case-acc,number-pl,gender-masc]).
correct_morph(671,7,[case-acc,number-pl,gender-masc]).
correct_morph(764,17,[case-gen,number-sg,gender-masc]).
correct_morph(764,19,[case-nom,number-sg,gender-masc]).
correct_morph(796,14,[case-dat,number-sg,gender-fem,degree-pos]).
correct_morph(796,15,[case-dat,number-sg,gender-fem]).
correct_morph(933,53,[]).
correct_morph(972,18,[case-acc,number-sg,gender-fem]).
correct_morph(1123,7,[case-gen,number-sg,gender-fem]).
correct_morph(1245,16,[case-gen,number-pl,gender-'*']).
correct_morph(1245,17,[case-gen,number-pl,gender-'*',degree-pos]).
correct_morph(1533,12,[case-acc,number-pl,gender-fem]).
correct_morph(1533,15,[case-acc,number-pl,gender-masc]).
correct_morph(2010,17,[case-dat,number-pl,gender-masc]).
correct_morph(2043,1,[case-nom,number-pl,gender-fem]).
correct_morph(2606,4,[case-gen,number-sg,gender-fem]).
correct_morph(2823,30,[]).
correct_morph(3235,12,[case-gen,number-sg,gender-masc,degree-pos]).
%correct_morph(3327,12,[case-nom,number-sg,gender-fem]). % Schreibfehler
correct_morph(3788,28,[case-gen,number-sg,gender-masc]).
correct_morph(4004,2,[case-nom,number-pl,gender-masc,degree-pos]).
correct_morph(4004,4,[case-nom,number-pl,gender-masc,degree-pos]).
correct_morph(4272,4,[case-nom,number-sg,gender-masc]).
correct_morph(4770,12,[degree-pos]).
correct_morph(4787,4,[case-acc,number-sg,gender-fem]).
correct_morph(4791,9,[case-acc,number-sg,gender-fem]).
correct_morph(4953,3,[case-nom,number-sg,gender-neut,person-3]).
correct_morph(4964,18,[case-nom,number-sg,gender-neut,person-3]).
correct_morph(5056,11,[case-dat,number-pl,gender-'*']).
correct_morph(5085,1,[case-nom,number-sg,gender-neut]).
correct_morph(5279,9,[case-dat,number-pl,gender-'*']).
correct_morph(5387,7,[case-acc,number-sg,gender-neut]).
correct_morph(5515,21,[case-'*',number-'*',gender-'*',degree-sup]).
correct_morph(5521,13,[case-nom,number-sg,gender-neut]).
correct_morph(5678,33,[case-gen,number-sg,gender-fem]).
correct_morph(5678,34,[case-gen,number-sg,gender-fem]).
correct_morph(5725,11,[case-acc,number-sg,gender-fem]). % coord
correct_morph(5900,38,[case-dat,number-pl,gender-masc,degree-pos]).
correct_morph(5900,39,[case-dat,number-pl,gender-masc]).
correct_morph(6088,18,[degree-pos]).
correct_morph(6169,43,[case-dat,number-sg,gender-masc,degree-pos]).
correct_morph(6357,7,[case-acc,number-sg,gender-masc]).
correct_morph(6658,20,[degree-pos]).
correct_morph(6806,10,[case-acc,number-pl,gender-'*']).
correct_morph(6812,25,[case-gen,number-pl,gender-'*']).
correct_morph(6886,7,[case-nom,number-sg,gender-masc]).
correct_morph(6895,9,[]).
correct_morph(6901,1,[case-nom,number-pl,gender-neut]).
correct_morph(6906,25,[case-acc,number-sg,gender-neut]).
correct_morph(6925,11,[case-gen,number-pl,gender-fem]).
correct_morph(7036,14,[case-acc,number-sg,gender-masc]).
correct_morph(7042,40,[case-acc,number-sg,gender-fem,degree-pos]).
correct_morph(7058,61,[]).
correct_morph(7265,10,[case-nom,number-pl,gender-masc]).
correct_morph(7581,4,[case-dat,number-pl,gender-'*']).
correct_morph(7666,16,[case-acc,number-sg,gender-fem]).
correct_morph(7670,10,[case-acc,number-sg,gender-fem]).
correct_morph(7698,3,[case-nom,number-sg,gender-neut,person-3]).
correct_morph(7767,5,[case-dat,number-pl,gender-'*',degree-sup]).
correct_morph(8080,16,[case-gen,number-sg,gender-masc]).
correct_morph(8080,17,[case-gen,number-sg,gender-masc]). % Schreibfehler (?)
correct_morph(8095,13,[case-gen,number-sg,gender-masc]).
correct_morph(8095,14,[case-gen,number-sg,gender-masc]).
correct_morph(8167,32,[case-dat,number-sg,gender-fem]).
correct_morph(8199,12,[case-acc,number-sg,gender-masc]).
correct_morph(8242,10,[case-gen,number-pl,gender-fem]).
correct_morph(8347,25,[case-acc,number-sg,gender-neut]).
correct_morph(8368,2,[case-nom,number-sg,gender-masc]).
correct_morph(8408,15,[]).
correct_morph(8408,16,[case-gen,number-sg,gender-fem]).
correct_morph(8408,17,[case-gen,number-sg,gender-fem]).
correct_morph(8484,4,[case-nom,number-pl,gender-neut]).
correct_morph(8489,2,[case-dat,number-pl,gender-masc]).
correct_morph(8511,6,[case-nom,number-sg,gender-neut,person-3]).
correct_morph(8513,8,[case-nom,number-sg,gender-neut,person-3]).
correct_morph(8568,13,[case-gen,number-sg,gender-fem]).
correct_morph(8626,2,[case-nom,number-pl,gender-fem,degree-pos]).
correct_morph(8626,3,[case-nom,number-pl,gender-fem]).
correct_morph(8634,8,[case-acc,number-pl,gender-neut]).
correct_morph(8734,1,[case-nom,number-sg,gender-neut,person-3]).
correct_morph(8901,27,[case-dat,number-sg,gender-fem]).
correct_morph(9405,20,[case-gen,number-sg,gender-masc]).
correct_morph(9797,12,[]).
correct_morph(9821,12,[]).
correct_morph(10053,1,[]).
correct_morph(10274,5,[case-gen,number-pl,gender-fem]).
correct_morph(10328,12,[case-gen,number-pl,gender-fem]).
correct_morph(10342,12,[case-gen,number-sg,gender-fem,degree-pos]).
correct_morph(10342,13,[case-gen,number-sg,gender-fem]).
correct_morph(10350,20,[case-acc,number-sg,gender-neut]).
correct_morph(10565,11,[case-acc,number-sg,gender-neut]).
correct_morph(10772,26,[case-gen,number-sg,gender-neut]).
correct_morph(10868,11,[case-gen,number-sg,gender-fem]).
correct_morph(11230,13,[]).
correct_morph(11358,5,[]).
correct_morph(11568,12,[case-gen,number-pl,gender-fem]).
correct_morph(11568,15,[case-nom,number-pl,gender-'*']).
correct_morph(11704,6,[case-gen,number-sg,gender-neut]).
correct_morph(12016,19,[case-gen,number-sg,gender-neut]).
correct_morph(12304,24,[case-acc,number-sg,gender-neut]).
correct_morph(12451,8,[]).
correct_morph(12583,3,[case-acc,number-sg,gender-neut]).
correct_morph(12669,16,[]).
correct_morph(12686,21,[case-gen,number-pl,gender-'*']).
correct_morph(12924,3,[]).
correct_morph(13473,43,[case-'*',number-'*',gender-'*',degree-sup]).
correct_morph(13635,17,[degree-sup]).
correct_morph(13843,28,[]).
correct_morph(13860,27,[case-gen,number-sg,gender-fem]).
correct_morph(13860,28,[case-gen,number-sg,gender-fem,degree-pos]).
correct_morph(13860,29,[case-gen,number-sg,gender-fem]).
correct_morph(14044,36,[case-acc,number-sg,gender-neut]).
correct_morph(14044,38,[case-acc,number-sg,gender-neut]).
correct_morph(14047,3,[case-acc,number-sg,gender-neut,person-'3']).
correct_morph(14208,7,[]).
correct_morph(14597,7,[degree-sup]).
correct_morph(14671,14,[case-nom,number-sg,gender-fem]).
correct_morph(15192,4,[case-acc,number-sg,gender-neut]).
correct_morph(15193,3,[case-acc,number-sg,gender-neut]).
correct_morph(15382,6,[case-acc,number-sg,gender-masc]).
correct_morph(16031,5,[]).
correct_morph(16055,10,[case-acc,number-pl,gender-'*']).
correct_morph(16057,6,[case-gen,number-pl,gender-'*']).
correct_morph(16401,9,[case-acc,number-sg,gender-masc]).
correct_morph(16478,3,[case-nom,number-sg,gender-neut]).
correct_morph(16570,20,[case-nom,number-sg,gender-fem]).
correct_morph(16570,21,[case-nom,number-sg,gender-neut]).
correct_morph(16552,38,[]).
correct_morph(16610,8,[case-nom,number-pl,gender-'*']).
correct_morph(16787,39,[degree-pos]).
correct_morph(16799,5,[case-acc,number-sg,gender-masc]).
correct_morph(16907,1,[case-nom,number-sg,gender-fem]).
correct_morph(17004,11,[case-gen,number-sg,gender-neut]).
correct_morph(17032,10,[case-gen,number-sg,gender-fem]).
correct_morph(17118,8,[case-dat,number-sg,gender-neut]).
correct_morph(17362,7,[case-acc,number-pl,gender-'*']).
correct_morph(17541,13,[case-gen,number-pl,gender-masc]).
correct_morph(17697,14,[case-gen,number-pl,gender-'*']).
correct_morph(17970,15,[case-nom,number-sg,gender-fem]).
correct_morph(18139,11,[degree-pos]).
correct_morph(19985,4,[case-dat,number-sg,gender-neut]).
correct_morph(20433,1,[case-acc,number-pl,gender-fem]).
correct_morph(20458,7,[case-gen,number-pl,gender-fem]).
correct_morph(20460,10,[]).
correct_morph(21426,2,[case-nom,number-sg,gender-fem]).
correct_morph(21490,1,[case-acc,number-sg,gender-neut]).
correct_morph(21495,1,[case-acc,number-sg,gender-neut]).
correct_morph(21662,46,[case-dat,number-sg,gender-masc]).
correct_morph(21675,36,[case-nom,number-sg,gender-masc]).
correct_morph(21676,5,[]).
correct_morph(21676,24,[case-dat,number-sg,gender-masc,degree-pos]).
correct_morph(21676,25,[case-dat,number-sg,gender-masc]).
correct_morph(21732,6,[case-acc,number-pl,gender-masc]).
correct_morph(21755,5,[case-nom,number-pl,gender-fem]).
correct_morph(21848,2,[case-dat,number-sg,gender-neut]).
correct_morph(21881,26,[case-dat,number-pl,gender-fem,degree-pos]).
correct_morph(21881,27,[case-dat,number-pl,gender-fem]).
correct_morph(21935,10,[case-gen,number-sg,gender-fem]).
correct_morph(21978,10,[case-gen,number-sg,gender-fem]).
correct_morph(21981,7,[case-acc,number-pl,gender-neut]).
correct_morph(21981,8,[case-acc,number-pl,gender-neut,degree-pos]).
correct_morph(22040,13,[case-acc,number-sg,gender-neut]).
correct_morph(22230,7,[case-nom,number-sg,gender-masc]).
correct_morph(22669,33,[case-acc,number-sg,gender-masc]).
correct_morph(22769,4,[case-acc,number-sg,gender-fem]).
correct_morph(22808,6,[case-nom,number-sg,gender-neut]).
correct_morph(22876,39,[case-acc,number-sg,gender-fem]).
correct_morph(23562,6,[case-nom,number-pl,gender-'*']).
correct_morph(24311,3,[case-gen,number-pl,gender-'*']).
correct_morph(24717,2,[case-nom,number-pl,gender-'*']).
correct_morph(24717,3,[case-nom,number-pl,gender-'*',degree-pos]).
correct_morph(24811,6,[case-gen,number-pl,gender-'*']).
correct_morph(24893,31,[case-gen,number-sg,gender-fem]).
correct_morph(24924,18,[case-gen,number-sg,gender-fem]).
correct_morph(25003,6,[case-gen,number-sg,gender-fem]).
correct_morph(25003,7,[case-gen,number-sg,gender-fem]).
correct_morph(25173,4,[case-acc,number-sg,gender-fem]).
correct_morph(25354,1,[case-nom,number-pl,gender-'*']).
correct_morph(25399,19,[case-dat,number-sg,gender-masc]).
correct_morph(25402,9,[case-gen,number-pl,gender-'*']).
correct_morph(25532,5,[case-gen,number-sg,gender-fem]).
correct_morph(25828,3,[case-nom,number-sg,gender-neut]).
correct_morph(25828,4,[case-nom,number-sg,gender-neut,degree-pos]).
correct_morph(25828,5,[case-nom,number-sg,gender-neut]).
correct_morph(26038,7,[case-gen,number-pl,gender-'*',degree-pos]).
correct_morph(26038,8,[case-gen,number-pl,gender-fem]).
correct_morph(26086,18,[case-dat,number-sg,gender-fem,degree-pos]).
correct_morph(26086,39,[case-dat,number-pl,gender-masc]).
correct_morph(26218,7,[case-nom,number-pl,gender-masc]).
correct_morph(26296,7,[case-dat,number-sg,gender-masc]).
correct_morph(26402,14,[case-acc,number-sg,gender-masc]).
correct_morph(26402,20,[case-acc,number-sg,gender-neut]).
correct_morph(26710,15,[case-dat,number-sg,gender-neut]).
correct_morph(26723,1,[case-nom,number-pl,gender-'*']).
correct_morph(26819,10,[case-gen,number-pl,gender-'*']).
correct_morph(27100,1,[case-acc,number-sg,gender-masc]).
correct_morph(27167,1,[case-acc,number-sg,gender-fem]).
correct_morph(27198,3,[]).
correct_morph(27247,10,[case-nom,number-pl,gender-masc]).
correct_morph(27265,37,[case-acc,number-pl,gender-masc]).
correct_morph(27265,46,[case-acc,number-pl,gender-neut]).
correct_morph(27265,47,[case-acc,number-pl,gender-neut]).
correct_morph(27333,6,[case-dat,number-sg,gender-neut]).
correct_morph(27357,18,[case-nom,number-sg,gender-neut]).
correct_morph(27371,7,[case-gen,number-sg,gender-fem]).
correct_morph(27423,7,[case-gen,number-sg,gender-fem]).
correct_morph(27497,18,[case-gen,number-pl,gender-'*']).
correct_morph(27538,8,[]).
correct_morph(27562,14,[case-acc,number-sg,gender-neut]).
correct_morph(27657,6,[case-gen,number-sg,gender-masc]).
correct_morph(27686,25,[case-nom,number-sg,gender-fem]).
correct_morph(27694,17,[case-dat,number-sg,gender-fem]).
correct_morph(27745,9,[case-nom,number-sg,gender-masc]).
correct_morph(27851,14,[case-gen,number-sg,gender-masc]).
correct_morph(27940,12,[case-nom,number-pl,gender-fem]).
correct_morph(27963,1,[case-acc,number-pl,gender-masc]).
correct_morph(28278,8,[case-dat,number-sg,gender-fem]).
correct_morph(28305,15,[case-acc,number-sg,gender-fem]).
correct_morph(28305,16,[case-acc,number-sg,gender-fem]).
correct_morph(28483,10,[case-gen,number-sg,gender-masc]).
correct_morph(28600,14,[case-nom,number-pl,gender-masc]).
correct_morph(28627,13,[case-nom,number-sg,gender-masc]).
correct_morph(28794,39,[case-dat,number-sg,person-'3']).
correct_morph(28837,10,[case-nom,number-sg,gender-fem]).
correct_morph(28873,38,[]).
correct_morph(28930,18,[case-acc,number-sg,gender-masc]).
correct_morph(28930,20,[case-acc,number-sg,gender-neut]).
correct_morph(28930,22,[case-acc,number-sg,gender-neut,degree-pos]).
correct_morph(28930,23,[case-acc,number-sg,gender-neut]).
correct_morph(28992,6,[case-nom,number-sg,gender-neut]).
correct_morph(29027,21,[case-gen,number-sg,gender-masc]).
correct_morph(29098,9,[]).
correct_morph(29102,20,[case-nom,number-sg,gender-neut]).
correct_morph(29156,10,[case-dat,number-pl,gender-'*']).
correct_morph(29156,11,[case-dat,number-pl,gender-masc]).
correct_morph(29283,8,[case-nom,number-pl,gender-fem]).
correct_morph(29548,2,[case-acc,number-sg,gender-neut,person-'3']).
correct_morph(29622,45,[case-acc,number-pl,gender-'*',person-'1']).
correct_morph(29624,21,[case-nom,number-sg,gender-masc]).
correct_morph(29624,62,[case-acc,number-pl,gender-'*',person-'1']).
correct_morph(29703,9,[case-nom,number-pl,gender-masc]).
correct_morph(29723,14,[case-gen,number-sg,gender-neut]).
correct_morph(29759,5,[case-nom,number-sg,gender-masc]).
correct_morph(29759,6,[case-nom,number-sg,gender-masc]).
correct_morph(29771,4,[case-gen,number-pl,gender-'*']).
correct_morph(29801,13,[case-acc,number-sg,gender-fem,degree-pos]).
correct_morph(29801,14,[case-acc,number-sg,gender-fem]).
correct_morph(29864,7,[case-gen,number-sg,gender-fem,degree-pos]).
correct_morph(29864,8,[case-gen,number-sg,gender-fem]).
correct_morph(30028,4,[]).
correct_morph(30323,10,[case-nom,number-sg,gender-neut]).
correct_morph(30323,12,[case-dat,number-sg,gender-neut]).
correct_morph(30522,5,[case-gen,number-pl,gender-'*']).
correct_morph(30522,8,[case-gen,number-pl,gender-fem]).
correct_morph(30794,14,[case-acc,number-pl,gender-masc]).
correct_morph(31035,1,[case-acc,number-sg,gender-fem]).
correct_morph(31536,5,[]).
correct_morph(31753,18,[]).
correct_morph(31954,1,[case-acc,number-pl,gender-'*']).
correct_morph(32515,31,[]).
correct_morph(32619,10,[degree-sup]).
correct_morph(32755,3,[]).
correct_morph(33249,7,[case-acc,number-sg,gender-neut]).
correct_morph(33271,7,[case-dat,number-sg,gender-masc]).
correct_morph(33667,13,[case-acc,number-sg,gender-neut]).
correct_morph(33784,12,[]).
correct_morph(33806,9,[]).
correct_morph(34400,7,[]).
correct_morph(34757,10,[degree-pos]).
correct_morph(36086,3,[]).
correct_morph(37668,28,[case-acc,number-pl,gender-fem,degree-pos]).
correct_morph(37668,29,[case-acc,number-pl,gender-fem]).
correct_morph(37725,15,[]).
correct_morph(38458,1,[case-acc,number-sg,gender-neut]).
correct_morph(39031,15,[case-acc,number-sg,gender-neut]).
correct_morph(39400,10,[case-dat,number-sg,gender-masc]).
correct_morph(40288,4,[case-dat,number-sg,gender-masc]).
correct_morph(40908,8,[case-acc,number-pl,gender-masc]).
correct_morph(40950,2,[case-acc,number-sg,gender-masc]).
correct_morph(41940,1,[case-acc,number-sg,gender-fem]).
correct_morph(42742,14,[case-acc,number-sg,gender-fem]).
correct_morph(42999,1,[]).
correct_morph(43642,1,[case-acc,number-pl,gender-fem]).
correct_morph(43643,1,[case-acc,number-sg,gender-masc]).
correct_morph(43644,1,[case-acc,number-sg,gender-neut]).
correct_morph(44679,1,[case-nom,number-sg,gender-neut]).
correct_morph(45640,11,[case-acc,number-sg,gender-neut]).
correct_morph(45670,11,[]).
correct_morph(45681,4,[case-dat,number-sg,person-'3']).
correct_morph(46152,6,[]).
correct_morph(46879,9,[]).
correct_morph(47853,8,[case-acc,number-sg,gender-fem]).
correct_morph(48362,21,[case-acc,number-sg,gender-neut]).
correct_morph(49488,1,[case-acc,number-'*',gender-neut]).
correct_morph(50129,4,[degree-sup]).
correct_morph(50227,21,[degree-sup]).
correct_morph(50236,24,[degree-sup]).
correct_morph(50404,7,[case-acc,number-sg,gender-neut]).
correct_morph(50427,20,[degree-sup]).

correct_morph(224,8,[]). % APPR
correct_morph(452,11,[]). % ADV
correct_morph(534,24,[]). % VVINF
correct_morph(1074,12,[case-dat,number-sg,gender-masc]). % APPRART
correct_morph(1435,17,[]). % APPR
correct_morph(1767,6,[case-gen,number-sg,gender-fem,person-'3']). % PPER
correct_morph(2675,6,[case-acc,number-pl,person-'3']). % PRF
correct_morph(3092,20,[]). % ADV
correct_morph(3122,24,[degree-pos]). % ADJD
correct_morph(3656,6,[case-acc,number-sg,gender-masc]). % PDAT
correct_morph(3936,21,[case-acc,number-pl,person-'3']). % PRF
correct_morph(4290,3,[number-pl,person-'1',tense-pres,mood-ind]). % VVFIN
correct_morph(4638,6,[case-dat,number-sg,gender-fem]). % APPRART
correct_morph(4670,30,[degree-comp]). % ADJD
correct_morph(5115,20,[degree-pos]). % ADJD
correct_morph(5379,22,[degree-pos]). % ADJD
correct_morph(5504,53,[degree-comp]). % ADJD
correct_morph(5515,20,[]). % PTKA
correct_morph(5515,21,[case-'*',number-'*',gender-'*']). % PIS
correct_morph(5539,3,[]). % CARD
correct_morph(5900,33,[degree-pos]). % ADJD
correct_morph(5904,26,[degree-pos]). % ADJD
correct_morph(7256,14,[]). % FM
correct_morph(7978,18,[case-'*',number-'*',gender-'*']). % NN
correct_morph(7986,21,[number-pl,person-'3',tense-pres,mood-ind]). % VVFIN
correct_morph(9186,7,[degree-comp]). % ADJD
correct_morph(9206,10,[degree-pos]). % ADJD
correct_morph(9393,1,[degree-pos]). % ADJD
correct_morph(9393,6,[degree-pos]). % ADJD
correct_morph(9397,7,[]). % APPR
correct_morph(9415,19,[case-'*',number-'*',gender-'*']). % NN
correct_morph(10370,19,[case-dat,number-sg,gender-fem,person-'3']). % PPER
correct_morph(10437,12,[case-acc,number-sg,gender-fem]). % PDAT
correct_morph(11121,14,[case-acc,number-sg,gender-fem,degree-pos]). % ADJA
correct_morph(11315,3,[case-dat,number-sg,gender-masc]). % PDAT
correct_morph(11315,24,[case-acc,number-sg,gender-masc]). % PDAT
correct_morph(11483,10,[case-acc,number-sg,gender-fem]). % PDAT
correct_morph(11605,14,[degree-pos]). % ADJD
correct_morph(12985,5,[case-acc,number-pl,person-'3']). % PRF
correct_morph(13084,30,[degree-pos]). % ADJD
correct_morph(13178,31,[case-gen,number-sg,gender-masc,degree-pos]). % ADJA
correct_morph(13392,15,[]). % PWAV
correct_morph(13473,42,[]). % PTKA
correct_morph(13473,43,[case-'*',number-'*',gender-'*']). % PIS
correct_morph(13635,16,[]). % PTKA
correct_morph(13694,4,[degree-pos]). % ADJD
correct_morph(13700,12,[degree-pos]). % ADJD
correct_morph(13750,7,[degree-pos]). % ADJD
correct_morph(13949,8,[degree-pos]). % ADJD
correct_morph(13984,4,[case-'*',number-'*',gender-'*']). % NN
correct_morph(14015,9,[case-dat,number-pl,person-'3']). % PRF
correct_morph(14041,27,[case-dat,number-sg,gender-neut,degree-pos]). % ADJA
correct_morph(14145,11,[case-acc,number-sg,gender-neut]). % NN
correct_morph(14230,16,[case-acc,number-pl,gender-fem]). % PDAT
correct_morph(14388,6,[case-gen,number-sg,gender-masc]). % PDAT
correct_morph(14427,5,[case-nom,number-sg,gender-masc,degree-pos]). % ADJA
correct_morph(14597,6,[]). % PTKA
correct_morph(14751,6,[]). % VVINF
correct_morph(14775,22,[case-acc,number-pl,person-'3']). % PRF
correct_morph(14795,7,[degree-pos]). % ADJD
correct_morph(14822,9,[degree-pos]). % ADJD
correct_morph(14825,7,[degree-pos]). % ADJD
correct_morph(14849,13,[]). % VVPP
correct_morph(14994,13,[degree-comp]). % ADJD
correct_morph(15916,5,[case-dat,number-sg,gender-masc]). % APPRART
correct_morph(19408,13,[degree-pos]). % ADJD
correct_morph(19626,2,[case-'*',number-'*',gender-'*']). % NE
correct_morph(19992,29,[degree-sup]). % ADJD
correct_morph(20195,9,[degree-pos]). % ADJD
correct_morph(20787,12,[case-nom,number-sg,gender-fem]). % NE
correct_morph(20929,23,[case-gen,number-sg,gender-neut]). % NE
correct_morph(21541,7,[degree-pos]). % ADJD
correct_morph(21881,25,[degree-pos]). % ADJD
correct_morph(21920,4,[degree-pos]). % ADJD
correct_morph(22243,43,[case-'*',number-'*',gender-'*']). % NN
correct_morph(22420,5,[case-acc,number-pl,person-'3']). % PRF
correct_morph(22529,2,[case-'*',number-'*',gender-'*']). % PIS
correct_morph(22736,22,[degree-pos]). % ADJD
correct_morph(23032,31,[degree-comp]). % ADJD
correct_morph(26232,8,[degree-pos]). % ADJD
correct_morph(26234,13,[degree-pos]). % ADJD
correct_morph(26952,19,[number-pl,person-'3',tense-pres,mood-ind]). % VVFIN
correct_morph(27238,12,[case-dat,number-sg,gender-masc]). % PDAT
correct_morph(27253,3,[degree-pos]). % ADJD
correct_morph(27253,4,[case-dat,number-sg,gender-fem]). % NN
correct_morph(27548,16,[case-'*',number-'*',gender-'*']). % NN
correct_morph(28463,24,[case-'*',number-'*',gender-'*']). % NN
correct_morph(29372,4,[]). % CARD
correct_morph(29372,5,[]). % CARD
correct_morph(29919,5,[]). % CARD
correct_morph(29958,6,[case-gen,number-pl,gender-'*',degree-pos]). % ADJA
correct_morph(30066,14,[case-'*',number-'*',gender-'*']). % NN
correct_morph(30153,23,[degree-pos]). % ADJD
correct_morph(30307,8,[degree-pos]). % ADJD
correct_morph(30315,1,[degree-pos]). % ADJD
correct_morph(30499,7,[case-gen,number-pl,gender-'*',degree-pos]). % ADJA
correct_morph(31110,5,[case-acc,number-sg,gender-masc]). % PDAT
correct_morph(31467,16,[degree-pos]). % ADJD
correct_morph(31757,7,[case-acc,number-sg,gender-neut]). % NN
correct_morph(32534,31,[degree-pos]). % ADJD
correct_morph(32770,4,[case-dat,number-pl,person-'3']). % PRF
correct_morph(34008,10,[degree-pos]). % ADJD
correct_morph(34084,16,[]). % ADV
correct_morph(34086,21,[]). % VVPP
correct_morph(34164,26,[degree-pos]). % ADJD
correct_morph(34166,32,[degree-pos]). % ADJD
correct_morph(35426,20,[degree-pos]). % ADJD
correct_morph(36818,29,[degree-pos]). % ADJD
correct_morph(36976,10,[case-dat,number-sg,gender-fem,person-'3']). % PPER
correct_morph(38682,3,[number-pl,person-'3',tense-pres,mood-ind]). % VVFIN
correct_morph(39337,28,[case-'*',number-'*',gender-'*']). % NN
correct_morph(39432,17,[case-'*',number-'*',gender-'*']). % NN
correct_morph(39752,9,[case-'*',number-'*',gender-'*']). % NN
correct_morph(40484,9,[]). % VVINF
correct_morph(40755,12,[degree-pos]). % ADJD
%correct_morph(41004,2,[]). % VVPP
correct_morph(41143,12,[degree-pos]). % ADJD
correct_morph(41583,7,[case-nom,number-pl,gender-fem]). % PDS
correct_morph(41686,7,[case-nom,number-pl,gender-'*']). % PIS
correct_morph(41816,20,[]). % CARD
correct_morph(42088,1,[degree-pos]). % ADJD
correct_morph(42158,9,[]). % VVPP
correct_morph(42304,1,[]). % VVPP
correct_morph(45759,21,[degree-pos]). % ADJD
correct_morph(46416,28,[degree-pos]). % ADJD
correct_morph(46708,1,[degree-pos]). % ADJD
correct_morph(48425,15,[degree-pos]). % ADJD
correct_morph(48431,19,[degree-pos]). % ADJD
correct_morph(48433,4,[degree-pos]). % ADJD
correct_morph(48450,7,[degree-pos]). % ADJD
correct_morph(48531,21,[]). % VMINF
correct_morph(48560,4,[degree-pos]). % ADJD
correct_morph(48732,1,[degree-pos]). % ADJD
correct_morph(48788,5,[degree-pos]). % ADJD
correct_morph(48924,3,[case-nom,number-pl,gender-'*',degree-pos]). % ADJA
correct_morph(49010,7,[degree-pos]). % ADJD
correct_morph(49022,62,[case-nom,number-sg,gender-'*']). % PIS
correct_morph(49532,25,[degree-pos]). % ADJD
correct_morph(50024,20,[case-nom,number-sg,gender-masc]). % PIS
correct_morph(50024,26,[case-nom,number-sg,gender-masc]). % PIS
correct_morph(50228,8,[case-nom,number-sg,gender-'*',person-'1']). % PPER
correct_morph(50469,3,[degree-pos]). % ADJD

correct_morph(53,3,[]). % ADV
correct_morph(183,10,[]). % ADV
correct_morph(274,15,[]). % ADV
correct_morph(293,3,[]). % ADV
correct_morph(294,19,[]). % ADV
correct_morph(306,18,[]). % ADV
correct_morph(326,6,[]). % ADV
correct_morph(567,9,[]). % ADV
correct_morph(613,8,[]). % ADV
correct_morph(625,8,[]). % ADV
correct_morph(643,4,[]). % ADV
correct_morph(658,3,[]). % ADV
correct_morph(670,2,[]). % ADV
correct_morph(683,20,[]). % ADV
correct_morph(688,7,[]). % ADV
correct_morph(800,11,[]). % ADV
correct_morph(804,10,[]). % ADV
correct_morph(841,9,[]). % ADV
correct_morph(1049,16,[]). % ADV
correct_morph(1049,21,[]). % ADV
correct_morph(1097,16,[]). % ADV
correct_morph(1177,7,[]). % ADV
correct_morph(1241,19,[]). % ADV
correct_morph(1245,13,[]). % ADV
correct_morph(1246,10,[]). % ADV
correct_morph(1263,12,[]). % ADV
correct_morph(1282,8,[]). % ADV
correct_morph(1284,5,[]). % ADV
correct_morph(1332,5,[]). % ADV
correct_morph(1375,18,[]). % ADV
correct_morph(1378,14,[]). % ADV
correct_morph(1440,16,[]). % ADV
correct_morph(1490,16,[]). % ADV
correct_morph(1507,15,[]). % ADV
correct_morph(1580,9,[]). % ADV
correct_morph(1630,10,[]). % ADV
correct_morph(1642,3,[]). % ADV
correct_morph(1777,18,[]). % ADV
correct_morph(1783,4,[]). % ADV
correct_morph(1789,9,[]). % ADV
correct_morph(1976,7,[]). % ADV
correct_morph(1984,9,[]). % ADV
correct_morph(2019,18,[]). % ADV
correct_morph(2067,5,[]). % ADV
correct_morph(2169,17,[]). % ADV
correct_morph(2221,10,[]). % ADV
correct_morph(2245,2,[]). % ADV
correct_morph(2269,8,[]). % ADV
correct_morph(2302,12,[]). % ADV
correct_morph(2320,7,[]). % ADV
correct_morph(2360,31,[]). % ADV
correct_morph(2466,7,[]). % ADV
correct_morph(2479,8,[]). % ADV
correct_morph(2483,4,[]). % ADV
correct_morph(2515,18,[]). % ADV
correct_morph(2555,7,[]). % ADV
correct_morph(2563,22,[]). % ADV
correct_morph(2565,9,[]). % ADV
correct_morph(2571,8,[]). % ADV
correct_morph(2819,2,[]). % ADV
correct_morph(2864,15,[]). % ADV
correct_morph(2867,15,[]). % ADV
correct_morph(2874,2,[]). % ADV
correct_morph(2963,9,[]). % ADV
correct_morph(2983,38,[]). % ADV
correct_morph(2986,6,[]). % ADV
correct_morph(2987,9,[]). % ADV
correct_morph(3064,28,[]). % ADV
correct_morph(3075,5,[]). % ADV
correct_morph(3172,18,[]). % ADV
correct_morph(3185,5,[]). % ADV
correct_morph(3231,40,[]). % ADV
correct_morph(3300,17,[]). % ADV
correct_morph(3329,2,[]). % ADV
correct_morph(3419,5,[]). % ADV
correct_morph(3420,3,[]). % ADV
correct_morph(3428,11,[]). % ADV
correct_morph(3430,12,[]). % ADV
correct_morph(3431,4,[]). % ADV
correct_morph(3434,4,[]). % ADV
correct_morph(3434,13,[]). % ADV
correct_morph(3435,9,[]). % ADV
correct_morph(3477,5,[]). % ADV
correct_morph(3558,18,[]). % ADV
correct_morph(3579,17,[]). % ADV
correct_morph(3581,4,[]). % ADV
correct_morph(3722,10,[]). % ADV
correct_morph(3768,7,[]). % ADV
correct_morph(3789,12,[]). % ADV
correct_morph(3789,17,[]). % ADV
correct_morph(3815,9,[]). % ADV
correct_morph(3816,8,[]). % ADV
correct_morph(3836,15,[]). % ADV
correct_morph(3849,15,[]). % ADV
correct_morph(3867,10,[]). % ADV
correct_morph(3889,19,[]). % ADV
correct_morph(3890,6,[]). % ADV
correct_morph(4109,11,[]). % ADV
correct_morph(4162,6,[]). % ADV
correct_morph(4243,26,[]). % ADV
correct_morph(4271,16,[]). % ADV
correct_morph(4274,2,[]). % ADV
correct_morph(4306,10,[]). % ADV
correct_morph(4404,13,[]). % ADV
correct_morph(4470,9,[]). % ADV
correct_morph(4498,21,[]). % ADV
correct_morph(4676,9,[]). % ADV
correct_morph(4749,13,[]). % ADV
correct_morph(5057,17,[]). % ADV
correct_morph(5843,4,[]). % ADV
correct_morph(6114,14,[]). % ADV
correct_morph(6123,16,[]). % ADV
correct_morph(6212,14,[]). % ADV
correct_morph(6260,15,[]). % ADV
correct_morph(6319,30,[]). % ADV
correct_morph(6347,8,[]). % ADV
correct_morph(6352,17,[]). % ADV
correct_morph(6413,12,[]). % ADV
correct_morph(6478,9,[]). % ADV
correct_morph(6703,15,[]). % ADV
correct_morph(6726,3,[]). % ADV
correct_morph(6747,24,[]). % ADV
correct_morph(6748,13,[]). % ADV
correct_morph(6764,20,[]). % ADV
correct_morph(6804,5,[]). % ADV
correct_morph(6816,8,[]). % ADV
correct_morph(7050,7,[]). % ADV
correct_morph(7134,18,[]). % ADV
correct_morph(7228,18,[]). % ADV
correct_morph(7527,36,[]). % ADV
correct_morph(7531,5,[]). % ADV
correct_morph(7532,11,[]). % ADV
correct_morph(7669,14,[]). % ADV
correct_morph(7766,15,[]). % ADV
correct_morph(7834,6,[]). % ADV
correct_morph(7842,8,[]). % ADV
correct_morph(7927,10,[]). % ADV
correct_morph(7989,10,[]). % ADV
correct_morph(8000,20,[]). % ADV
correct_morph(8148,4,[]). % ADV
correct_morph(8177,7,[]). % ADV
correct_morph(8271,2,[]). % ADV
correct_morph(8388,5,[]). % ADV
correct_morph(8390,24,[]). % ADV
correct_morph(8423,4,[]). % ADV
correct_morph(8501,18,[]). % ADV
correct_morph(8558,13,[]). % ADV
correct_morph(8651,2,[]). % ADV
correct_morph(8653,6,[]). % ADV
correct_morph(8664,12,[]). % ADV
correct_morph(8666,10,[]). % ADV
correct_morph(8675,3,[]). % ADV
correct_morph(8676,6,[]). % ADV
correct_morph(8684,5,[]). % ADV
correct_morph(8728,14,[]). % ADV
correct_morph(9129,2,[]). % ADV
correct_morph(9147,14,[]). % ADV
correct_morph(9270,4,[]). % ADV
correct_morph(9271,10,[]). % ADV
correct_morph(9299,22,[]). % ADV
correct_morph(9488,6,[]). % ADV
correct_morph(9803,13,[]). % ADV
correct_morph(9875,14,[]). % ADV
correct_morph(9919,4,[]). % ADV
correct_morph(10028,23,[]). % ADV
correct_morph(10122,2,[]). % ADV
correct_morph(10141,10,[]). % ADV
correct_morph(10230,10,[]). % ADV
correct_morph(10373,14,[]). % ADV
correct_morph(10408,6,[]). % ADV
correct_morph(10445,5,[]). % ADV
correct_morph(10495,10,[]). % ADV
correct_morph(10712,10,[]). % ADV
correct_morph(10736,22,[]). % ADV
correct_morph(10827,14,[]). % ADV
correct_morph(10901,20,[]). % ADV
correct_morph(10965,8,[]). % ADV
correct_morph(11098,10,[]). % ADV
correct_morph(11695,7,[]). % ADV
correct_morph(11788,19,[]). % ADV
correct_morph(11830,18,[]). % ADV
correct_morph(11881,12,[]). % ADV
correct_morph(11914,22,[]). % ADV
correct_morph(11960,16,[]). % ADV
correct_morph(12025,10,[]). % ADV
correct_morph(12159,10,[]). % ADV
correct_morph(12187,17,[]). % ADV
correct_morph(12187,23,[]). % ADV
correct_morph(12209,2,[]). % ADV
correct_morph(12253,2,[]). % ADV
correct_morph(12330,4,[]). % ADV
correct_morph(12520,18,[]). % ADV
correct_morph(12668,13,[]). % ADV
correct_morph(12721,10,[]). % ADV
correct_morph(12728,12,[]). % ADV
correct_morph(12788,18,[]). % ADV
correct_morph(12788,22,[]). % ADV
correct_morph(12788,27,[]). % ADV
correct_morph(12813,8,[]). % ADV
correct_morph(12815,7,[]). % ADV
correct_morph(12903,9,[]). % ADV
correct_morph(12910,17,[]). % ADV
correct_morph(13127,14,[]). % ADV
correct_morph(13183,10,[]). % ADV
correct_morph(13317,16,[]). % ADV
correct_morph(13405,16,[]). % ADV
correct_morph(13411,26,[]). % ADV
correct_morph(13540,13,[]). % ADV
correct_morph(13634,10,[]). % ADV
correct_morph(13759,8,[]). % ADV
correct_morph(13871,6,[]). % ADV
correct_morph(13985,16,[]). % ADV
correct_morph(14044,24,[]). % ADV
correct_morph(14142,14,[]). % ADV
correct_morph(14145,7,[]). % ADV
correct_morph(14151,7,[]). % ADV
correct_morph(14151,11,[]). % ADV
correct_morph(14153,4,[]). % ADV
correct_morph(14161,3,[]). % ADV
correct_morph(14162,7,[]). % ADV
correct_morph(14181,7,[]). % ADV
correct_morph(14184,14,[]). % ADV
correct_morph(14188,2,[]). % ADV
correct_morph(14198,7,[]). % ADV
correct_morph(14216,10,[]). % ADV
correct_morph(14261,10,[]). % ADV
correct_morph(14582,5,[]). % ADV
correct_morph(14747,12,[]). % ADV
correct_morph(14822,10,[]). % ADV
correct_morph(14902,6,[]). % ADV
correct_morph(14932,16,[]). % ADV
correct_morph(14949,29,[]). % ADV
correct_morph(14986,7,[]). % ADV
correct_morph(14987,4,[]). % ADV
correct_morph(15091,14,[]). % ADV
correct_morph(15143,11,[]). % ADV
correct_morph(15288,8,[]). % ADV
correct_morph(15289,11,[]). % ADV
correct_morph(15602,38,[]). % ADV
correct_morph(15664,8,[]). % ADV
correct_morph(15726,9,[]). % ADV
correct_morph(15766,2,[]). % ADV
correct_morph(15768,10,[]). % ADV
correct_morph(15780,25,[]). % ADV
correct_morph(15845,8,[]). % ADV
correct_morph(15845,19,[]). % ADV
correct_morph(15981,20,[]). % ADV
correct_morph(16200,27,[]). % ADV
correct_morph(16274,8,[]). % ADV
correct_morph(16294,6,[]). % ADV
correct_morph(16348,2,[]). % ADV
correct_morph(16360,5,[]). % ADV
correct_morph(16675,34,[]). % ADV
correct_morph(16802,12,[]). % ADV
correct_morph(16910,2,[]). % ADV
correct_morph(16927,6,[]). % ADV
correct_morph(16966,2,[]). % ADV
correct_morph(17232,30,[]). % ADV
correct_morph(17275,9,[]). % ADV
correct_morph(17476,2,[]). % ADV
correct_morph(17502,18,[]). % ADV
correct_morph(17503,7,[]). % ADV
correct_morph(17504,3,[]). % ADV
correct_morph(17509,3,[]). % ADV
correct_morph(17509,6,[]). % ADV
correct_morph(17524,10,[]). % ADV
correct_morph(17784,17,[]). % ADV
correct_morph(17786,5,[]). % ADV
correct_morph(17915,27,[]). % ADV
correct_morph(18012,8,[]). % ADV
correct_morph(18068,6,[]). % ADV
correct_morph(18098,16,[]). % ADV
correct_morph(18115,29,[]). % ADV
correct_morph(18475,6,[]). % ADV
correct_morph(18631,6,[]). % ADV
correct_morph(18668,18,[]). % ADV
correct_morph(18674,15,[]). % ADV
correct_morph(18704,7,[]). % ADV
correct_morph(18723,5,[]). % ADV
correct_morph(18743,12,[]). % ADV
correct_morph(18806,5,[]). % ADV
correct_morph(18817,25,[]). % ADV
correct_morph(19031,11,[]). % ADV
correct_morph(19083,9,[]). % ADV
correct_morph(19085,12,[]). % ADV
correct_morph(19098,7,[]). % ADV
correct_morph(19539,15,[]). % ADV
correct_morph(19626,11,[]). % ADV
correct_morph(19627,10,[]). % ADV
correct_morph(19628,10,[]). % ADV
correct_morph(19722,2,[]). % ADV
correct_morph(19722,10,[]). % ADV
correct_morph(19781,7,[]). % ADV
correct_morph(19784,9,[]). % ADV
correct_morph(20131,9,[]). % ADV
correct_morph(20181,25,[]). % ADV
correct_morph(20384,17,[]). % ADV
correct_morph(20433,2,[]). % ADV
correct_morph(20458,8,[]). % ADV
correct_morph(20461,16,[]). % ADV
correct_morph(20508,11,[]). % ADV
correct_morph(20516,11,[]). % ADV
correct_morph(20683,7,[]). % ADV
correct_morph(20685,14,[]). % ADV
correct_morph(20689,14,[]). % ADV
correct_morph(20742,25,[]). % ADV
correct_morph(20749,11,[]). % ADV
correct_morph(20750,2,[]). % ADV
correct_morph(20842,11,[]). % ADV
correct_morph(20843,18,[]). % ADV
correct_morph(20901,17,[]). % ADV
correct_morph(21075,11,[]). % ADV
correct_morph(21080,2,[]). % ADV
correct_morph(21100,6,[]). % ADV
correct_morph(21102,2,[]). % ADV
correct_morph(21232,14,[]). % ADV
correct_morph(21300,16,[]). % ADV
correct_morph(21308,17,[]). % ADV
correct_morph(21331,15,[]). % ADV
correct_morph(21376,5,[]). % ADV
correct_morph(21434,2,[]). % ADV
correct_morph(21441,10,[]). % ADV
correct_morph(21470,8,[]). % ADV
correct_morph(21471,12,[]). % ADV
correct_morph(21558,10,[]). % ADV
correct_morph(21728,2,[]). % ADV
correct_morph(21733,18,[]). % ADV
correct_morph(21812,15,[]). % ADV
correct_morph(21886,4,[]). % ADV
correct_morph(22372,14,[]). % ADV
correct_morph(22377,12,[]). % ADV
correct_morph(22490,18,[]). % ADV
correct_morph(22494,8,[]). % ADV
correct_morph(22496,13,[]). % ADV
correct_morph(22521,21,[]). % ADV
correct_morph(22664,20,[]). % ADV
correct_morph(22669,27,[]). % ADV
correct_morph(22718,3,[]). % ADV
correct_morph(22728,18,[]). % ADV
correct_morph(22975,3,[]). % ADV
correct_morph(22981,13,[]). % ADV
correct_morph(22992,4,[]). % ADV
correct_morph(23153,8,[]). % ADV
correct_morph(23386,8,[]). % ADV
correct_morph(23547,6,[]). % ADV
correct_morph(23599,5,[]). % ADV
correct_morph(23618,11,[]). % ADV
correct_morph(23655,8,[]). % ADV
correct_morph(23705,21,[]). % ADV
correct_morph(23891,17,[]). % ADV
correct_morph(23892,5,[]). % ADV
correct_morph(24145,5,[]). % ADV
correct_morph(24160,17,[]). % ADV
correct_morph(24194,9,[]). % ADV
correct_morph(24374,19,[]). % ADV
correct_morph(24476,12,[]). % ADV
correct_morph(24478,8,[]). % ADV
correct_morph(24494,10,[]). % ADV
correct_morph(24617,7,[]). % ADV
correct_morph(24627,2,[]). % ADV
correct_morph(24790,16,[]). % ADV
correct_morph(24971,39,[]). % ADV
correct_morph(25120,21,[]). % ADV
correct_morph(25196,12,[]). % ADV
correct_morph(25262,6,[]). % ADV
correct_morph(25399,7,[]). % ADV
correct_morph(25492,15,[]). % ADV
correct_morph(25505,9,[]). % ADV
correct_morph(25507,12,[]). % ADV
correct_morph(25547,4,[]). % ADV
correct_morph(25571,15,[]). % ADV
correct_morph(25592,2,[]). % ADV
correct_morph(25643,3,[]). % ADV
correct_morph(25698,19,[]). % ADV
correct_morph(25724,11,[]). % ADV
correct_morph(25744,19,[]). % ADV
correct_morph(25754,10,[]). % ADV
correct_morph(25767,13,[]). % ADV
correct_morph(25877,6,[]). % ADV
correct_morph(25932,19,[]). % ADV
correct_morph(25940,9,[]). % ADV
correct_morph(26022,16,[]). % ADV
correct_morph(26043,8,[]). % ADV
correct_morph(26396,8,[]). % ADV
correct_morph(26406,14,[]). % ADV
correct_morph(26729,13,[]). % ADV
correct_morph(26971,5,[]). % ADV
correct_morph(27054,5,[]). % ADV
correct_morph(27144,10,[]). % ADV
correct_morph(27151,11,[]). % ADV
correct_morph(27191,11,[]). % ADV
correct_morph(27211,12,[]). % ADV
correct_morph(27302,12,[]). % ADV
correct_morph(27316,10,[]). % ADV
correct_morph(27320,35,[]). % ADV
correct_morph(27471,25,[]). % ADV
correct_morph(27473,19,[]). % ADV
correct_morph(27543,12,[]). % ADV
correct_morph(27549,22,[]). % ADV
correct_morph(27550,22,[]). % ADV
correct_morph(27573,2,[]). % ADV
correct_morph(27764,12,[]). % ADV
correct_morph(27811,13,[]). % ADV
correct_morph(27812,22,[]). % ADV
correct_morph(27818,5,[]). % ADV
correct_morph(28185,5,[]). % ADV
correct_morph(28186,19,[]). % ADV
correct_morph(28297,12,[]). % ADV
correct_morph(28306,18,[]). % ADV
correct_morph(28306,22,[]). % ADV
correct_morph(28310,15,[]). % ADV
correct_morph(28312,6,[]). % ADV
correct_morph(28342,6,[]). % ADV
correct_morph(28405,10,[]). % ADV
correct_morph(28450,8,[]). % ADV
correct_morph(28484,21,[]). % ADV
correct_morph(28548,11,[]). % ADV
correct_morph(28743,3,[]). % ADV
correct_morph(28872,16,[]). % ADV
correct_morph(28908,13,[]). % ADV
correct_morph(28981,4,[]). % ADV
correct_morph(28981,11,[]). % ADV
correct_morph(29026,11,[]). % ADV
correct_morph(29147,5,[]). % ADV
correct_morph(29148,12,[]). % ADV
correct_morph(29547,4,[]). % ADV
correct_morph(29598,6,[]). % ADV
correct_morph(29685,6,[]). % ADV
correct_morph(29706,4,[]). % ADV
correct_morph(29711,9,[]). % ADV
correct_morph(29731,18,[]). % ADV
correct_morph(29777,16,[]). % ADV
correct_morph(29778,11,[]). % ADV
correct_morph(29786,11,[]). % ADV
correct_morph(29800,21,[]). % ADV
correct_morph(29825,25,[]). % ADV
correct_morph(29832,18,[]). % ADV
correct_morph(29865,6,[]). % ADV
correct_morph(29957,13,[]). % ADV
correct_morph(30038,7,[]). % ADV
correct_morph(30136,7,[]). % ADV
correct_morph(30177,11,[]). % ADV
correct_morph(30177,26,[]). % ADV
correct_morph(30187,13,[]). % ADV
correct_morph(30192,9,[]). % ADV
correct_morph(30251,5,[]). % ADV
correct_morph(30667,11,[]). % ADV
correct_morph(30863,21,[]). % ADV
correct_morph(30864,11,[]). % ADV
correct_morph(31047,7,[]). % ADV
correct_morph(31080,8,[]). % ADV
correct_morph(31162,5,[]). % ADV
correct_morph(31482,11,[]). % ADV
correct_morph(32078,12,[]). % ADV
correct_morph(32079,9,[]). % ADV
correct_morph(32625,8,[]). % ADV
correct_morph(32919,14,[]). % ADV
correct_morph(33058,7,[]). % ADV
correct_morph(33230,9,[]). % ADV
correct_morph(34050,7,[]). % ADV
correct_morph(34629,3,[]). % ADV
correct_morph(35080,5,[]). % ADV
correct_morph(35145,6,[]). % ADV
correct_morph(35150,8,[]). % ADV
correct_morph(35220,3,[]). % ADV
correct_morph(35305,6,[]). % ADV
correct_morph(35352,5,[]). % ADV
correct_morph(35389,16,[]). % ADV
correct_morph(35438,18,[]). % ADV
correct_morph(35547,9,[]). % ADV
correct_morph(35560,9,[]). % ADV
correct_morph(35563,6,[]). % ADV
correct_morph(35582,13,[]). % ADV
correct_morph(35863,14,[]). % ADV
correct_morph(35868,10,[]). % ADV
correct_morph(36019,44,[]). % ADV
correct_morph(36021,3,[]). % ADV
correct_morph(36238,4,[]). % ADV
correct_morph(36278,7,[]). % ADV
correct_morph(36278,16,[]). % ADV
correct_morph(36310,10,[]). % ADV
correct_morph(36313,7,[]). % ADV
correct_morph(36470,6,[]). % ADV
correct_morph(36513,6,[]). % ADV
correct_morph(36513,10,[]). % ADV
correct_morph(36544,18,[]). % ADV
correct_morph(36545,16,[]). % ADV
correct_morph(36546,7,[]). % ADV
correct_morph(36571,4,[]). % ADV
correct_morph(36575,7,[]). % ADV
correct_morph(36625,5,[]). % ADV
correct_morph(36644,7,[]). % ADV
correct_morph(36654,38,[]). % ADV
correct_morph(36679,5,[]). % ADV
correct_morph(36698,6,[]). % ADV
correct_morph(36698,12,[]). % ADV
correct_morph(36708,6,[]). % ADV
correct_morph(36709,7,[]). % ADV
correct_morph(36710,12,[]). % ADV
correct_morph(36715,17,[]). % ADV
correct_morph(36731,10,[]). % ADV
correct_morph(36795,3,[]). % ADV
correct_morph(36812,19,[]). % ADV
correct_morph(36827,21,[]). % ADV
correct_morph(36831,8,[]). % ADV
correct_morph(36838,5,[]). % ADV
correct_morph(36864,7,[]). % ADV
correct_morph(36885,3,[]). % ADV
correct_morph(36889,8,[]). % ADV
correct_morph(36919,17,[]). % ADV
correct_morph(36940,30,[]). % ADV
correct_morph(36945,11,[]). % ADV
correct_morph(36957,9,[]). % ADV
correct_morph(36969,13,[]). % ADV
correct_morph(36998,16,[]). % ADV
correct_morph(37049,22,[]). % ADV
correct_morph(37064,25,[]). % ADV
correct_morph(37108,5,[]). % ADV
correct_morph(37109,14,[]). % ADV
correct_morph(37132,15,[]). % ADV
correct_morph(37198,32,[]). % ADV
correct_morph(37198,36,[]). % ADV
correct_morph(37238,7,[]). % ADV
correct_morph(37239,12,[]). % ADV
correct_morph(37251,9,[]). % ADV
correct_morph(37252,14,[]). % ADV
correct_morph(37283,34,[]). % ADV
correct_morph(37287,21,[]). % ADV
correct_morph(37307,12,[]). % ADV
correct_morph(37318,8,[]). % ADV
correct_morph(37318,16,[]). % ADV
correct_morph(37350,16,[]). % ADV
correct_morph(37377,13,[]). % ADV
correct_morph(37387,27,[]). % ADV
correct_morph(37448,12,[]). % ADV
correct_morph(37448,20,[]). % ADV
correct_morph(37471,21,[]). % ADV
correct_morph(37490,4,[]). % ADV
correct_morph(37504,27,[]). % ADV
correct_morph(37509,16,[]). % ADV
correct_morph(37512,18,[]). % ADV
correct_morph(37516,9,[]). % ADV
correct_morph(37557,15,[]). % ADV
correct_morph(37582,8,[]). % ADV
correct_morph(37584,14,[]). % ADV
correct_morph(37590,18,[]). % ADV
correct_morph(37754,10,[]). % ADV
correct_morph(37759,2,[]). % ADV
correct_morph(37804,18,[]). % ADV
correct_morph(37807,4,[]). % ADV
correct_morph(37894,12,[]). % ADV
correct_morph(37926,3,[]). % ADV
correct_morph(37929,10,[]). % ADV
correct_morph(37952,16,[]). % ADV
correct_morph(38011,13,[]). % ADV
correct_morph(38078,5,[]). % ADV
correct_morph(38101,8,[]). % ADV
correct_morph(38104,12,[]). % ADV
correct_morph(38104,16,[]). % ADV
correct_morph(38105,8,[]). % ADV
correct_morph(38114,18,[]). % ADV
correct_morph(38115,12,[]). % ADV
correct_morph(38116,3,[]). % ADV
correct_morph(38119,5,[]). % ADV
correct_morph(38125,35,[]). % ADV
correct_morph(38243,13,[]). % ADV
correct_morph(38275,6,[]). % ADV
correct_morph(38327,4,[]). % ADV
correct_morph(38328,9,[]). % ADV
correct_morph(38331,20,[]). % ADV
correct_morph(38332,10,[]). % ADV
correct_morph(38333,10,[]). % ADV
correct_morph(38334,2,[]). % ADV
correct_morph(38381,11,[]). % ADV
correct_morph(38389,10,[]). % ADV
correct_morph(38543,9,[]). % ADV
correct_morph(38544,23,[]). % ADV
correct_morph(38627,15,[]). % ADV
correct_morph(38662,19,[]). % ADV
correct_morph(38829,2,[]). % ADV
correct_morph(38837,3,[]). % ADV
correct_morph(38865,5,[]). % ADV
correct_morph(38894,13,[]). % ADV
correct_morph(38909,4,[]). % ADV
correct_morph(38922,23,[]). % ADV
correct_morph(38923,10,[]). % ADV
correct_morph(38961,5,[]). % ADV
correct_morph(39014,3,[]). % ADV
correct_morph(39030,12,[]). % ADV
correct_morph(39066,31,[]). % ADV
correct_morph(39072,22,[]). % ADV
correct_morph(39074,13,[]). % ADV
correct_morph(39099,3,[]). % ADV
correct_morph(39101,4,[]). % ADV
correct_morph(39151,14,[]). % ADV
correct_morph(39163,14,[]). % ADV
correct_morph(39164,12,[]). % ADV
correct_morph(39208,4,[]). % ADV
correct_morph(39224,11,[]). % ADV
correct_morph(39226,6,[]). % ADV
correct_morph(39230,16,[]). % ADV
correct_morph(39233,12,[]). % ADV
correct_morph(39250,10,[]). % ADV
correct_morph(39262,17,[]). % ADV
correct_morph(39272,11,[]). % ADV
correct_morph(39307,21,[]). % ADV
correct_morph(39308,6,[]). % ADV
correct_morph(39337,21,[]). % ADV
correct_morph(39348,10,[]). % ADV
correct_morph(39361,18,[]). % ADV
correct_morph(39361,27,[]). % ADV
correct_morph(39392,12,[]). % ADV
correct_morph(39426,7,[]). % ADV
correct_morph(39452,33,[]). % ADV
correct_morph(39454,3,[]). % ADV
correct_morph(39472,22,[]). % ADV
correct_morph(39484,8,[]). % ADV
correct_morph(39507,20,[]). % ADV
correct_morph(39519,16,[]). % ADV
correct_morph(39520,17,[]). % ADV
correct_morph(39534,7,[]). % ADV
correct_morph(39584,11,[]). % ADV
correct_morph(39594,8,[]). % ADV
correct_morph(39601,11,[]). % ADV
correct_morph(39609,28,[]). % ADV
correct_morph(39636,6,[]). % ADV
correct_morph(39648,23,[]). % ADV
correct_morph(39689,7,[]). % ADV
correct_morph(39705,6,[]). % ADV
correct_morph(39904,25,[]). % ADV
correct_morph(39910,19,[]). % ADV
correct_morph(39939,16,[]). % ADV
correct_morph(39987,10,[]). % ADV
correct_morph(40017,10,[]). % ADV
correct_morph(40020,10,[]). % ADV
correct_morph(40022,14,[]). % ADV
correct_morph(40023,8,[]). % ADV
correct_morph(40023,15,[]). % ADV
correct_morph(40032,19,[]). % ADV
correct_morph(40033,5,[]). % ADV
correct_morph(40034,4,[]). % ADV
correct_morph(40049,6,[]). % ADV
correct_morph(40060,10,[]). % ADV
correct_morph(40075,10,[]). % ADV
correct_morph(40099,9,[]). % ADV
correct_morph(40205,7,[]). % ADV
correct_morph(40244,12,[]). % ADV
correct_morph(40250,18,[]). % ADV
correct_morph(40250,30,[]). % ADV
correct_morph(40253,16,[]). % ADV
correct_morph(40310,2,[]). % ADV
correct_morph(40323,5,[]). % ADV
correct_morph(40325,9,[]). % ADV
correct_morph(40328,9,[]). % ADV
correct_morph(40339,15,[]). % ADV
correct_morph(40362,15,[]). % ADV
correct_morph(40376,11,[]). % ADV
correct_morph(40413,12,[]). % ADV
correct_morph(40421,15,[]). % ADV
correct_morph(40444,9,[]). % ADV
correct_morph(40448,19,[]). % ADV
correct_morph(40457,15,[]). % ADV
correct_morph(40458,6,[]). % ADV
correct_morph(40458,13,[]). % ADV
correct_morph(40467,6,[]). % ADV
correct_morph(40468,3,[]). % ADV
correct_morph(40476,6,[]). % ADV
correct_morph(40497,2,[]). % ADV
correct_morph(40497,8,[]). % ADV
correct_morph(40507,23,[]). % ADV
correct_morph(40537,5,[]). % ADV
correct_morph(40617,8,[]). % ADV
correct_morph(40630,2,[]). % ADV
correct_morph(40630,21,[]). % ADV
correct_morph(40702,21,[]). % ADV
correct_morph(40703,17,[]). % ADV
correct_morph(40718,9,[]). % ADV
correct_morph(40737,8,[]). % ADV
correct_morph(40739,8,[]). % ADV
correct_morph(40746,6,[]). % ADV
correct_morph(40750,13,[]). % ADV
correct_morph(40785,17,[]). % ADV
correct_morph(40796,4,[]). % ADV
correct_morph(40807,8,[]). % ADV
correct_morph(40814,2,[]). % ADV
correct_morph(40822,19,[]). % ADV
correct_morph(40832,14,[]). % ADV
correct_morph(40835,7,[]). % ADV
correct_morph(40837,5,[]). % ADV
correct_morph(40909,11,[]). % ADV
correct_morph(40920,12,[]). % ADV
correct_morph(40958,25,[]). % ADV
correct_morph(40960,10,[]). % ADV
correct_morph(41002,8,[]). % ADV
correct_morph(41005,14,[]). % ADV
correct_morph(41005,22,[]). % ADV
correct_morph(41031,21,[]). % ADV
correct_morph(41032,9,[]). % ADV
correct_morph(41051,14,[]). % ADV
correct_morph(41075,23,[]). % ADV
correct_morph(41075,28,[]). % ADV
correct_morph(41076,24,[]). % ADV
correct_morph(41088,10,[]). % ADV
correct_morph(41123,10,[]). % ADV
correct_morph(41127,6,[]). % ADV
correct_morph(41140,16,[]). % ADV
correct_morph(41151,18,[]). % ADV
correct_morph(41153,16,[]). % ADV
correct_morph(41172,5,[]). % ADV
correct_morph(41191,24,[]). % ADV
correct_morph(41219,5,[]). % ADV
correct_morph(41227,15,[]). % ADV
correct_morph(41267,12,[]). % ADV
correct_morph(41278,22,[]). % ADV
correct_morph(41313,23,[]). % ADV
correct_morph(41321,11,[]). % ADV
correct_morph(41325,12,[]). % ADV
correct_morph(41356,1,[]). % ADV
correct_morph(41360,7,[]). % ADV
correct_morph(41390,6,[]). % ADV
correct_morph(41390,18,[]). % ADV
correct_morph(41401,11,[]). % ADV
correct_morph(41415,53,[]). % ADV
correct_morph(41454,14,[]). % ADV
correct_morph(41523,9,[]). % ADV
correct_morph(41540,11,[]). % ADV
correct_morph(41544,8,[]). % ADV
correct_morph(41544,13,[]). % ADV
correct_morph(41597,4,[]). % ADV
correct_morph(41628,5,[]). % ADV
correct_morph(41629,9,[]). % ADV
correct_morph(41634,16,[]). % ADV
correct_morph(41659,12,[]). % ADV
correct_morph(41665,5,[]). % ADV
correct_morph(41684,6,[]). % ADV
correct_morph(41686,10,[]). % ADV
correct_morph(41716,13,[]). % ADV
correct_morph(41721,23,[]). % ADV
correct_morph(41725,6,[]). % ADV
correct_morph(41757,13,[]). % ADV
correct_morph(41771,9,[]). % ADV
correct_morph(41775,12,[]). % ADV
correct_morph(41786,8,[]). % ADV
correct_morph(41844,22,[]). % ADV
correct_morph(41845,15,[]). % ADV
correct_morph(41887,9,[]). % ADV
correct_morph(41904,6,[]). % ADV
correct_morph(41909,22,[]). % ADV
correct_morph(41922,3,[]). % ADV
correct_morph(41955,7,[]). % ADV
correct_morph(41980,4,[]). % ADV
correct_morph(41992,18,[]). % ADV
correct_morph(42048,13,[]). % ADV
correct_morph(42091,3,[]). % ADV
correct_morph(42153,18,[]). % ADV
correct_morph(42219,25,[]). % ADV
correct_morph(42238,7,[]). % ADV
correct_morph(42247,22,[]). % ADV
correct_morph(42282,2,[]). % ADV
correct_morph(42286,7,[]). % ADV
correct_morph(42296,7,[]). % ADV
correct_morph(42300,7,[]). % ADV
correct_morph(42328,5,[]). % ADV
correct_morph(42361,19,[]). % ADV
correct_morph(42368,9,[]). % ADV
correct_morph(42368,16,[]). % ADV
correct_morph(42369,11,[]). % ADV
correct_morph(42410,25,[]). % ADV
correct_morph(42411,10,[]). % ADV
correct_morph(42440,5,[]). % ADV
correct_morph(42445,11,[]). % ADV
correct_morph(42483,27,[]). % ADV
correct_morph(42509,17,[]). % ADV
correct_morph(42510,4,[]). % ADV
correct_morph(42518,8,[]). % ADV
correct_morph(42525,2,[]). % ADV
correct_morph(42528,6,[]). % ADV
correct_morph(42574,12,[]). % ADV
correct_morph(42584,25,[]). % ADV
correct_morph(42591,3,[]). % ADV
correct_morph(42593,5,[]). % ADV
correct_morph(42595,14,[]). % ADV
correct_morph(42609,7,[]). % ADV
correct_morph(42623,7,[]). % ADV
correct_morph(42654,2,[]). % ADV
correct_morph(42799,8,[]). % ADV
correct_morph(42809,18,[]). % ADV
correct_morph(42820,8,[]). % ADV
correct_morph(42820,15,[]). % ADV
correct_morph(42824,14,[]). % ADV
correct_morph(42841,3,[]). % ADV
correct_morph(42873,5,[]). % ADV
correct_morph(42875,15,[]). % ADV
correct_morph(42899,13,[]). % ADV
correct_morph(42908,9,[]). % ADV
correct_morph(43005,13,[]). % ADV
correct_morph(43014,5,[]). % ADV
correct_morph(43018,16,[]). % ADV
correct_morph(43018,22,[]). % ADV
correct_morph(43025,2,[]). % ADV
correct_morph(43051,5,[]). % ADV
correct_morph(43052,6,[]). % ADV
correct_morph(43092,4,[]). % ADV
correct_morph(43110,11,[]). % ADV
correct_morph(43112,9,[]). % ADV
correct_morph(43113,16,[]). % ADV
correct_morph(43129,13,[]). % ADV
correct_morph(43137,21,[]). % ADV
correct_morph(43166,8,[]). % ADV
correct_morph(43176,9,[]). % ADV
correct_morph(43178,11,[]). % ADV
correct_morph(43203,14,[]). % ADV
correct_morph(43220,3,[]). % ADV
correct_morph(43249,6,[]). % ADV
correct_morph(43274,14,[]). % ADV
correct_morph(43301,7,[]). % ADV
correct_morph(43307,18,[]). % ADV
correct_morph(43337,10,[]). % ADV
correct_morph(43344,7,[]). % ADV
correct_morph(43355,6,[]). % ADV
correct_morph(43363,13,[]). % ADV
correct_morph(43373,10,[]). % ADV
correct_morph(43380,10,[]). % ADV
correct_morph(43396,14,[]). % ADV
correct_morph(43399,6,[]). % ADV
correct_morph(43412,14,[]). % ADV
correct_morph(43419,7,[]). % ADV
correct_morph(43425,10,[]). % ADV
correct_morph(43428,9,[]). % ADV
correct_morph(43428,20,[]). % ADV
correct_morph(43429,11,[]). % ADV
correct_morph(43443,20,[]). % ADV
correct_morph(43448,9,[]). % ADV
correct_morph(43470,13,[]). % ADV
correct_morph(43471,16,[]). % ADV
correct_morph(43478,14,[]). % ADV
correct_morph(43491,12,[]). % ADV
correct_morph(43498,25,[]). % ADV
correct_morph(43498,33,[]). % ADV
correct_morph(43517,16,[]). % ADV
correct_morph(43524,15,[]). % ADV
correct_morph(43538,5,[]). % ADV
correct_morph(43589,10,[]). % ADV
correct_morph(43676,8,[]). % ADV
correct_morph(43683,18,[]). % ADV
correct_morph(43684,7,[]). % ADV
correct_morph(43745,11,[]). % ADV
correct_morph(43750,31,[]). % ADV
correct_morph(43759,7,[]). % ADV
correct_morph(43773,6,[]). % ADV
correct_morph(43785,16,[]). % ADV
correct_morph(43802,13,[]). % ADV
correct_morph(43805,10,[]). % ADV
correct_morph(43822,13,[]). % ADV
correct_morph(43828,16,[]). % ADV
correct_morph(43863,12,[]). % ADV
correct_morph(43868,6,[]). % ADV
correct_morph(43869,23,[]). % ADV
correct_morph(43877,16,[]). % ADV
correct_morph(43917,3,[]). % ADV
correct_morph(43965,12,[]). % ADV
correct_morph(43969,6,[]). % ADV
correct_morph(43971,12,[]). % ADV
correct_morph(43991,8,[]). % ADV
correct_morph(44015,24,[]). % ADV
correct_morph(44019,26,[]). % ADV
correct_morph(44023,18,[]). % ADV
correct_morph(44033,5,[]). % ADV
correct_morph(44035,22,[]). % ADV
correct_morph(44073,14,[]). % ADV
correct_morph(44074,19,[]). % ADV
correct_morph(44081,5,[]). % ADV
correct_morph(44098,13,[]). % ADV
correct_morph(44113,7,[]). % ADV
correct_morph(44145,26,[]). % ADV
correct_morph(44201,12,[]). % ADV
correct_morph(44266,4,[]). % ADV
correct_morph(44296,17,[]). % ADV
correct_morph(44306,5,[]). % ADV
correct_morph(44306,10,[]). % ADV
correct_morph(44315,8,[]). % ADV
correct_morph(44321,3,[]). % ADV
correct_morph(44330,12,[]). % ADV
correct_morph(44331,12,[]). % ADV
correct_morph(44384,10,[]). % ADV
correct_morph(44387,5,[]). % ADV
correct_morph(44387,13,[]). % ADV
correct_morph(44509,10,[]). % ADV
correct_morph(44517,8,[]). % ADV
correct_morph(44518,5,[]). % ADV
correct_morph(44630,23,[]). % ADV
correct_morph(44636,20,[]). % ADV
correct_morph(44696,14,[]). % ADV
correct_morph(44739,4,[]). % ADV
correct_morph(44758,26,[]). % ADV
correct_morph(44783,7,[]). % ADV
correct_morph(44884,21,[]). % ADV
correct_morph(44902,12,[]). % ADV
correct_morph(44912,5,[]). % ADV
correct_morph(44947,6,[]). % ADV
correct_morph(45156,8,[]). % ADV
correct_morph(45307,12,[]). % ADV
correct_morph(45392,10,[]). % ADV
correct_morph(45438,5,[]). % ADV
correct_morph(45440,25,[]). % ADV
correct_morph(45456,12,[]). % ADV
correct_morph(45529,12,[]). % ADV
correct_morph(45546,3,[]). % ADV
correct_morph(45768,13,[]). % ADV
correct_morph(45780,6,[]). % ADV
correct_morph(45782,4,[]). % ADV
correct_morph(45788,18,[]). % ADV
correct_morph(45798,8,[]). % ADV
correct_morph(45859,2,[]). % ADV
correct_morph(45929,31,[]). % ADV
correct_morph(46015,11,[]). % ADV
correct_morph(46380,17,[]). % ADV
correct_morph(46431,20,[]). % ADV
correct_morph(46549,31,[]). % ADV
correct_morph(46627,21,[]). % ADV
correct_morph(46771,23,[]). % ADV
correct_morph(46845,3,[]). % ADV
correct_morph(46939,8,[]). % ADV
correct_morph(46953,2,[]). % ADV
correct_morph(47092,6,[]). % ADV
correct_morph(47154,48,[]). % ADV
correct_morph(47216,53,[]). % ADV
correct_morph(47262,15,[]). % ADV
correct_morph(47265,5,[]). % ADV
correct_morph(47267,4,[]). % ADV
correct_morph(47268,4,[]). % ADV
correct_morph(47277,17,[]). % ADV
correct_morph(47400,20,[]). % ADV
correct_morph(47597,28,[]). % ADV
correct_morph(47804,11,[]). % ADV
correct_morph(48152,3,[]). % ADV
correct_morph(48185,17,[]). % ADV
correct_morph(48242,8,[]). % ADV
correct_morph(49087,7,[]). % ADV
correct_morph(49208,21,[]). % ADV
correct_morph(49405,28,[]). % ADV
correct_morph(49597,7,[]). % ADV

% subjects that did not have a nominative case:
correct_morph(705,19,[case-nom,number-pl,gender-fem]).
correct_morph(4345,21,[case-nom,number-sg,gender-neut,person-'3']).
correct_morph(5373,15,[case-nom,number-sg,gender-neut,person-'3']).
correct_morph(13432,21,[case-nom,number-sg,gender-fem]).
correct_morph(13432,22,[case-nom,number-sg,gender-fem]).
correct_morph(15377,1,[case-nom,number-sg,gender-neut,person-'3']).
correct_morph(16657,5,[case-nom,number-sg,gender-neut]).
correct_morph(17629,2,[case-nom,number-sg,gender-neut,person-'3']).
correct_morph(17724,3,[case-nom,number-sg,gender-neut,person-'3']).
correct_morph(17740,2,[case-nom,number-sg,gender-neut,person-'3']).
correct_morph(19782,7,[case-nom,number-pl,gender-fem]).
correct_morph(21830,32,[case-nom,number-pl,gender-fem]).
correct_morph(22710,14,[case-nom,number-sg,gender-masc]).
correct_morph(22774,9,[case-nom,number-sg,gender-masc]).
correct_morph(22774,10,[case-nom,number-sg,gender-masc]).
correct_morph(22777,1,[case-nom,number-sg,gender-masc]).
correct_morph(22777,2,[case-nom,number-sg,gender-masc]).
correct_morph(22783,5,[case-nom,number-sg,gender-masc]).
correct_morph(22783,6,[case-nom,number-sg,gender-masc]).
correct_morph(22786,7,[case-nom,number-sg,gender-masc]).
correct_morph(22786,8,[case-nom,number-sg,gender-masc]).
correct_morph(22789,8,[case-nom,number-sg,gender-masc]).
correct_morph(22789,9,[case-nom,number-sg,gender-masc]).
correct_morph(26206,14,[case-nom,number-sg,gender-neut]).
correct_morph(27351,25,[case-nom,number-sg,gender-neut]).
correct_morph(28602,18,[case-nom,number-pl,gender-neut]).
correct_morph(28844,3,[case-nom,number-sg,gender-neut]).
correct_morph(28844,4,[case-nom,number-sg,gender-neut]).
correct_morph(28914,4,[case-nom,number-sg,gender-masc]).
correct_morph(29520,3,[case-nom,number-sg,gender-fem,degree-pos]).
correct_morph(29520,4,[case-nom,number-sg,gender-fem]).
correct_morph(29699,3,[case-nom,number-pl,gender-fem]).
correct_morph(30148,31,[case-nom,number-sg,gender-masc]).
correct_morph(31405,14,[case-nom,number-sg,gender-neut]).
correct_morph(32151,17,[case-nom,number-sg,gender-neut,degree-pos]).
correct_morph(32151,18,[case-nom,number-sg,gender-neut]).
correct_morph(33045,5,[case-nom,number-sg,gender-fem]).
correct_morph(33715,10,[case-nom,number-pl,gender-masc]).
correct_morph(33922,1,[case-nom,number-sg,gender-neut,person-'3']).
correct_morph(34764,4,[case-nom,number-sg,gender-neut]).
correct_morph(36259,2,[case-nom,number-pl,gender-'*']).
correct_morph(37204,19,[case-nom,number-sg,gender-neut]).
correct_morph(40468,5,[case-nom,number-pl,gender-fem]).
correct_morph(40537,2,[case-nom,number-sg,gender-fem]).
correct_morph(41140,10,[case-nom,number-pl,gender-neut]).
correct_morph(41192,26,[case-nom,number-sg,gender-masc]).
correct_morph(41287,11,[case-nom,number-sg,gender-masc]).
correct_morph(41724,5,[case-nom,number-sg,gender-masc]).
correct_morph(41783,10,[case-nom,number-sg,gender-fem]).
correct_morph(41867,27,[case-nom,number-sg,gender-fem]).
correct_morph(41955,10,[case-nom,number-sg,gender-fem]).
correct_morph(42388,3,[case-nom,number-sg,gender-masc]).
correct_morph(42972,2,[case-nom,number-pl,gender-masc,degree-pos]).
correct_morph(42972,3,[case-nom,number-pl,gender-masc]).
correct_morph(42982,3,[case-nom,number-pl,gender-masc,degree-pos]).
correct_morph(42982,4,[case-nom,number-pl,gender-masc]).
correct_morph(43015,7,[case-nom,number-pl,gender-masc,degree-pos]).
correct_morph(43015,8,[case-nom,number-pl,gender-masc]).
correct_morph(43245,3,[case-nom,number-pl,gender-'*']).
correct_morph(43470,15,[case-nom,number-sg,gender-neut]).
correct_morph(43517,18,[case-nom,number-sg,gender-neut]).
correct_morph(48591,10,[case-nom,number-sg,gender-fem]).
correct_morph(48609,4,[case-nom,number-sg,gender-masc]).
correct_morph(49418,9,[case-nom,number-sg,gender-masc]).

correct_morph(33168,35,[case-nom,number-sg,gender-masc]).
correct_morph(34788,6,[case-nom,number-sg,gender-fem]).
correct_morph(37060,10,[case-nom,number-pl,gender-neut]).
correct_morph(37060,11,[case-nom,number-pl,gender-neut]).






% 18547
% 22516 weitere solcher Runden -> falsch analysiert
% 28844_4 orchester sb oder obj?
% 43517 NP missing inside PP for genitive object
correct_poscat(30,1,proav).
correct_poscat(53,3,adv).
correct_poscat(93,5,proav).
correct_poscat(183,10,adv).
correct_poscat(224,8,appr).
correct_poscat(274,15,adv).
correct_poscat(277,8,proav).
correct_poscat(293,3,adv).
correct_poscat(294,19,adv).
correct_poscat(306,18,adv).
correct_poscat(326,6,adv).
correct_poscat(363,16,appr).
correct_poscat(434,5,appr).
correct_poscat(444,12,kokom).
correct_poscat(452,11,adv).
correct_poscat(452,506,avp).
correct_poscat(488,34,pis).
correct_poscat(496,500,np).
correct_poscat(534,24,vvinf).
correct_poscat(536,29,ptkvz).
correct_poscat(555,23,pis).
correct_poscat(567,9,adv).
correct_poscat(613,8,adv).
correct_poscat(625,8,adv).
correct_poscat(643,4,adv).
correct_poscat(658,3,adv).
correct_poscat(670,2,adv).
correct_poscat(683,20,adv).
correct_poscat(688,7,adv).
correct_poscat(800,11,adv).
correct_poscat(804,10,adv).
correct_poscat(824,501,np).
correct_poscat(836,500,np).
correct_poscat(841,9,adv).
correct_poscat(867,511,np).
correct_poscat(933,53,appr).
correct_poscat(933,516,pp).
correct_poscat(972,18,pdat).
correct_poscat(1049,16,adv).
correct_poscat(1049,21,adv).
correct_poscat(1074,12,apprart).
correct_poscat(1097,16,adv).
correct_poscat(1177,7,adv).
correct_poscat(1241,19,adv).
correct_poscat(1245,13,adv).
correct_poscat(1246,10,adv).
correct_poscat(1263,12,adv).
correct_poscat(1282,8,adv).
correct_poscat(1284,5,adv).
correct_poscat(1332,5,adv).
correct_poscat(1375,18,adv).
correct_poscat(1378,14,adv).
correct_poscat(1435,17,appr).
correct_poscat(1435,504,pp).
correct_poscat(1440,16,adv).
correct_poscat(1490,16,adv).
correct_poscat(1507,15,adv).
correct_poscat(1580,9,adv).
correct_poscat(1630,10,adv).
correct_poscat(1642,3,adv).
correct_poscat(1767,6,pper).
correct_poscat(1777,18,adv).
correct_poscat(1783,4,adv).
correct_poscat(1789,9,adv).
correct_poscat(1945,2,pis).
correct_poscat(1976,7,adv).
correct_poscat(1984,9,adv).
correct_poscat(2013,10,pwav).
correct_poscat(2019,18,adv).
correct_poscat(2046,43,adv).
correct_poscat(2067,5,adv).
correct_poscat(2090,507,np).
correct_poscat(2169,17,adv).
correct_poscat(2221,10,adv).
correct_poscat(2245,2,adv).
correct_poscat(2269,8,adv).
correct_poscat(2302,12,adv).
correct_poscat(2320,7,adv).
correct_poscat(2360,31,adv).
correct_poscat(2424,9,pwav).
correct_poscat(2466,7,adv).
correct_poscat(2479,8,adv).
correct_poscat(2483,4,adv).
correct_poscat(2515,18,adv).
correct_poscat(2555,7,adv).
correct_poscat(2563,22,adv).
correct_poscat(2565,9,adv).
correct_poscat(2571,8,adv).
correct_poscat(2675,6,prf).
correct_poscat(2770,503,np).
correct_poscat(2789,14,ptkvz).
correct_poscat(2819,2,adv).
correct_poscat(2819,500,avp).
correct_poscat(2823,30,adv).
correct_poscat(2864,15,adv).
correct_poscat(2867,15,adv).
correct_poscat(2874,2,adv).
correct_poscat(2943,12,pwav).
correct_poscat(2963,9,adv).
correct_poscat(2983,38,adv).
correct_poscat(2986,6,adv).
correct_poscat(2987,9,adv).
correct_poscat(3026,11,pwav).
correct_poscat(3052,23,pis).
correct_poscat(3063,17,pwav).
correct_poscat(3064,28,adv).
correct_poscat(3075,5,adv).
correct_poscat(3092,20,adv).
correct_poscat(3122,24,adjd).
correct_poscat(3172,18,adv).
correct_poscat(3185,5,adv).
correct_poscat(3231,40,adv).
correct_poscat(3300,17,adv).
correct_poscat(3329,2,adv).
correct_poscat(3406,1,koui).
correct_poscat(3419,5,adv).
correct_poscat(3420,3,adv).
correct_poscat(3428,11,adv).
correct_poscat(3430,12,adv).
correct_poscat(3431,4,adv).
correct_poscat(3434,13,adv).
correct_poscat(3434,4,adv).
correct_poscat(3435,9,adv).
correct_poscat(3477,5,adv).
correct_poscat(3558,18,adv).
correct_poscat(3579,17,adv).
correct_poscat(3581,4,adv).
correct_poscat(3656,6,pdat).
correct_poscat(3722,10,adv).
correct_poscat(3768,7,adv).
correct_poscat(3789,12,adv).
correct_poscat(3789,17,adv).
correct_poscat(3815,9,adv).
correct_poscat(3816,8,adv).
correct_poscat(3836,15,adv).
correct_poscat(3849,15,adv).
correct_poscat(3867,10,adv).
correct_poscat(3889,19,adv).
correct_poscat(3890,6,adv).
correct_poscat(3936,21,prf).
correct_poscat(4010,1,proav).
correct_poscat(4042,1,proav).
correct_poscat(4109,11,adv).
correct_poscat(4112,500,aa).
correct_poscat(4162,6,adv).
correct_poscat(4191,14,kokom).
correct_poscat(4191,505,ap).
correct_poscat(4243,26,adv).
correct_poscat(4271,16,adv).
correct_poscat(4274,2,adv).
correct_poscat(4290,3,vvfin).
correct_poscat(4306,10,adv).
correct_poscat(4308,505,np).
correct_poscat(4404,13,adv).
correct_poscat(4427,500,s).
correct_poscat(4468,6,kokom).
correct_poscat(4470,9,adv).
correct_poscat(4498,21,adv).
correct_poscat(4520,18,proav).
correct_poscat(4532,1,proav).
correct_poscat(4572,4,proav).
correct_poscat(4582,14,pwav).
correct_poscat(4619,11,appr).
correct_poscat(4638,6,apprart).
correct_poscat(4672,6,proav).
correct_poscat(4676,9,adv).
correct_poscat(4749,13,adv).
correct_poscat(4770,12,adjd).
correct_poscat(4801,1,piat).
correct_poscat(4956,18,pis).
correct_poscat(5057,17,adv).
correct_poscat(5085,1,nn).
correct_poscat(5088,31,koui).
correct_poscat(5088,504,avp).
correct_poscat(5115,20,adjd).
correct_poscat(5214,3,proav).
correct_poscat(5240,29,proav).
correct_poscat(5318,20,pds).
correct_poscat(5323,49,vvinf).
correct_poscat(5379,22,adjd).
correct_poscat(5515,20,ptka).
correct_poscat(5515,504,aa).
correct_poscat(5517,19,pis).
correct_poscat(5539,2,adv).
correct_poscat(5539,3,card).
correct_poscat(5552,507,isu).
correct_poscat(5592,500,np).
correct_poscat(5762,4,adv).
correct_poscat(5827,501,avp).
correct_poscat(5843,4,adv).
correct_poscat(5857,23,koui).
correct_poscat(5874,3,pper).
correct_poscat(5900,29,pds).
correct_poscat(5900,33,adjd).
correct_poscat(5904,26,adjd).
correct_poscat(6068,15,appo).
correct_poscat(6088,18,adjd).
correct_poscat(6114,14,adv).
correct_poscat(6123,16,adv).
correct_poscat(6143,1,proav).
correct_poscat(6152,505,avp).
correct_poscat(6176,1,proav).
correct_poscat(6212,14,adv).
correct_poscat(6260,15,adv).
correct_poscat(6319,30,adv).
correct_poscat(6347,8,adv).
correct_poscat(6352,17,adv).
correct_poscat(6413,12,adv).
correct_poscat(6478,9,adv).
correct_poscat(6480,1,proav).
correct_poscat(6658,20,adjd).
correct_poscat(6703,15,adv).
correct_poscat(6726,3,adv).
correct_poscat(6747,24,adv).
correct_poscat(6748,13,adv).
correct_poscat(6764,20,adv).
correct_poscat(6804,5,adv).
correct_poscat(6816,8,adv).
correct_poscat(6895,9,adv).
correct_poscat(7024,2,'$(').
correct_poscat(7035,500,cap).
correct_poscat(7047,17,ptkvz).
correct_poscat(7050,7,adv).
correct_poscat(7058,61,appr).
correct_poscat(7058,513,pp).
correct_poscat(7134,18,adv).
correct_poscat(7228,18,adv).
correct_poscat(7256,13,fm).
correct_poscat(7256,14,fm).
correct_poscat(7289,505,avp).
correct_poscat(7320,506,ap).
correct_poscat(7343,508,avp).
correct_poscat(7429,14,ptkvz).
correct_poscat(7457,2,pis).
correct_poscat(7527,36,adv).
correct_poscat(7531,5,adv).
correct_poscat(7532,11,adv).
correct_poscat(7637,1,proav).
correct_poscat(7669,14,adv).
correct_poscat(7766,15,adv).
correct_poscat(7767,5,adja).
correct_poscat(7834,6,adv).
correct_poscat(7842,8,adv).
correct_poscat(7880,1,proav).
correct_poscat(7891,2,kous).
correct_poscat(7927,10,adv).
correct_poscat(7972,25,ptkzu).
correct_poscat(7978,18,nn).
correct_poscat(7986,21,vvfin).
correct_poscat(7986,505,s).
correct_poscat(7989,10,adv).
correct_poscat(8000,20,adv).
correct_poscat(8058,502,np).
correct_poscat(8067,500,avp).
correct_poscat(8108,519,ap).
correct_poscat(8148,4,adv).
correct_poscat(8177,7,adv).
correct_poscat(8258,501,np).
correct_poscat(8271,2,adv).
correct_poscat(8388,5,adv).
correct_poscat(8390,24,adv).
correct_poscat(8390,516,avp).
correct_poscat(8408,15,appr).
correct_poscat(8408,507,pp).
correct_poscat(8423,4,adv).
correct_poscat(8501,18,adv).
correct_poscat(8558,13,adv).
correct_poscat(8651,2,adv).
correct_poscat(8653,6,adv).
correct_poscat(8664,12,adv).
correct_poscat(8666,10,adv).
correct_poscat(8675,3,adv).
correct_poscat(8676,6,adv).
correct_poscat(8684,5,adv).
correct_poscat(8712,7,pis).
correct_poscat(8728,14,adv).
correct_poscat(8732,509,vz).
correct_poscat(8804,9,prels).
correct_poscat(8963,502,pp).
correct_poscat(9129,2,adv).
correct_poscat(9147,14,adv).
correct_poscat(9199,504,avp).
correct_poscat(9206,10,adjd).
correct_poscat(9270,4,adv).
correct_poscat(9271,10,adv).
correct_poscat(9299,22,adv).
correct_poscat(9319,2,proav).
correct_poscat(9380,12,appr).
correct_poscat(9393,1,adjd).
correct_poscat(9393,6,adjd).
correct_poscat(9397,7,appr).
correct_poscat(9397,513,pp).
correct_poscat(9403,22,pis).
correct_poscat(9415,19,nn).
correct_poscat(9488,6,adv).
correct_poscat(9769,16,pis).
correct_poscat(9797,12,adv).
correct_poscat(9803,13,adv).
correct_poscat(9821,12,adv).
correct_poscat(9875,14,adv).
correct_poscat(9919,4,adv).
correct_poscat(10028,23,adv).
correct_poscat(10038,7,kokom).
correct_poscat(10053,1,appr).
correct_poscat(10053,504,pp).
correct_poscat(10122,2,adv).
correct_poscat(10141,10,adv).
correct_poscat(10230,10,adv).
correct_poscat(10350,20,nn).
correct_poscat(10370,19,pper).
correct_poscat(10373,14,adv).
correct_poscat(10408,6,adv).
correct_poscat(10437,12,pdat).
correct_poscat(10445,5,adv).
correct_poscat(10495,10,adv).
correct_poscat(10565,11,nn).
correct_poscat(10712,10,adv).
correct_poscat(10736,22,adv).
correct_poscat(10827,14,adv).
correct_poscat(10901,20,adv).
correct_poscat(10965,8,adv).
correct_poscat(11098,10,adv).
correct_poscat(11121,14,adja).
correct_poscat(11230,13,appr).
correct_poscat(11230,501,pp).
correct_poscat(11299,22,appr).
correct_poscat(11314,11,adv).
correct_poscat(11314,12,adv).
correct_poscat(11314,501,np).
correct_poscat(11315,3,pdat).
correct_poscat(11315,5,apzr).
correct_poscat(11315,24,pdat).
correct_poscat(11358,5,adv).
correct_poscat(11483,10,pdat).
correct_poscat(11575,14,pwav).
correct_poscat(11605,14,adjd).
correct_poscat(11695,7,adv).
correct_poscat(11766,16,appr).
correct_poscat(11788,19,adv).
correct_poscat(11830,18,adv).
correct_poscat(11881,12,adv).
correct_poscat(11914,22,adv).
correct_poscat(11960,16,adv).
correct_poscat(12025,10,adv).
correct_poscat(12066,3,pds).
correct_poscat(12159,10,adv).
correct_poscat(12187,17,adv).
correct_poscat(12187,23,adv).
correct_poscat(12209,2,adv).
correct_poscat(12253,2,adv).
correct_poscat(12304,24,nn).
correct_poscat(12330,4,adv).
correct_poscat(12451,8,adv).
correct_poscat(12520,18,adv).
correct_poscat(12583,3,nn).
correct_poscat(12668,13,adv).
correct_poscat(12669,16,appr).
correct_poscat(12669,502,pp).
correct_poscat(12683,501,np).
correct_poscat(12721,10,adv).
correct_poscat(12728,12,adv).
correct_poscat(12785,505,np).
correct_poscat(12788,18,adv).
correct_poscat(12788,22,adv).
correct_poscat(12788,27,adv).
correct_poscat(12813,8,adv).
correct_poscat(12815,7,adv).
correct_poscat(12903,9,adv).
correct_poscat(12910,17,adv).
correct_poscat(12924,3,adv).
correct_poscat(12985,5,prf).
correct_poscat(12993,31,pis).
correct_poscat(13084,30,adjd).
correct_poscat(13125,8,appr).
correct_poscat(13127,14,adv).
correct_poscat(13178,31,adja).
correct_poscat(13183,10,adv).
correct_poscat(13207,1,proav).
correct_poscat(13267,18,proav).
correct_poscat(13295,4,pis).
correct_poscat(13296,2,proav).
correct_poscat(13314,7,pis).
correct_poscat(13317,16,adv).
correct_poscat(13392,15,pwav).
correct_poscat(13405,16,adv).
correct_poscat(13411,26,adv).
correct_poscat(13444,1,proav).
correct_poscat(13473,42,ptka).
correct_poscat(13473,509,aa).
correct_poscat(13540,13,adv).
correct_poscat(13634,10,adv).
correct_poscat(13635,16,ptka).
correct_poscat(13635,17,adjd).
correct_poscat(13635,504,aa).
correct_poscat(13694,4,adjd).
correct_poscat(13700,12,adjd).
correct_poscat(13750,7,adjd).
correct_poscat(13759,8,adv).
correct_poscat(13843,28,adv).
correct_poscat(13871,6,adv).
correct_poscat(13940,17,pds).
correct_poscat(13949,8,adjd).
correct_poscat(13950,12,pis).
correct_poscat(13950,14,pis).
correct_poscat(13984,3,appr).
correct_poscat(13984,4,nn).
correct_poscat(13985,16,adv).
correct_poscat(14015,9,prf).
correct_poscat(14017,17,pds).
correct_poscat(14041,27,adja).
correct_poscat(14044,24,adv).
correct_poscat(14044,514,avp).
correct_poscat(14142,14,adv).
correct_poscat(14145,7,adv).
correct_poscat(14145,11,nn).
correct_poscat(14151,11,adv).
correct_poscat(14151,7,adv).
correct_poscat(14153,4,adv).
correct_poscat(14161,3,adv).
correct_poscat(14162,7,adv).
correct_poscat(14181,7,adv).
correct_poscat(14184,14,adv).
correct_poscat(14188,2,adv).
correct_poscat(14198,7,adv).
correct_poscat(14208,7,appr).
correct_poscat(14208,501,pp).
correct_poscat(14215,1,kous).
correct_poscat(14216,10,adv).
correct_poscat(14230,16,pdat).
correct_poscat(14243,514,s).
correct_poscat(14261,10,adv).
correct_poscat(14272,6,koui).
correct_poscat(14272,7,art).
correct_poscat(14291,23,kon).
correct_poscat(14301,27,pis).
correct_poscat(14304,5,pis).
correct_poscat(14314,1,adv).
correct_poscat(14386,501,aa).
correct_poscat(14388,6,pdat).
correct_poscat(14427,5,adja).
correct_poscat(14459,33,pds).
correct_poscat(14494,2,pis).
correct_poscat(14559,1,appr).
correct_poscat(14582,5,adv).
correct_poscat(14590,8,pis).
correct_poscat(14597,6,ptka).
correct_poscat(14597,7,adjd).
correct_poscat(14597,500,aa).
correct_poscat(14635,19,appr).
correct_poscat(14635,502,pp).
correct_poscat(14671,11,pwav).
correct_poscat(14747,12,adv).
correct_poscat(14751,6,vvinf).
correct_poscat(14775,22,prf).
correct_poscat(14792,6,pis).
correct_poscat(14795,7,adjd).
correct_poscat(14802,11,pds).
correct_poscat(14822,9,adjd).
correct_poscat(14822,10,adv).
correct_poscat(14825,7,adjd).
correct_poscat(14849,13,vvpp).
correct_poscat(14902,6,adv).
correct_poscat(14932,16,adv).
correct_poscat(14949,29,adv).
correct_poscat(14986,7,adv).
correct_poscat(14987,4,adv).
correct_poscat(15056,7,adv).
correct_poscat(15091,14,adv).
correct_poscat(15107,3,ptkvz).
correct_poscat(15143,11,adv).
correct_poscat(15192,4,nn).
correct_poscat(15193,3,nn).
correct_poscat(15288,8,adv).
correct_poscat(15289,11,adv).
correct_poscat(15573,500,np).
correct_poscat(15602,38,adv).
correct_poscat(15664,8,adv).
correct_poscat(15726,9,adv).
correct_poscat(15736,1,adv).
correct_poscat(15766,2,adv).
correct_poscat(15768,10,adv).
correct_poscat(15780,25,adv).
correct_poscat(15845,19,adv).
correct_poscat(15845,8,adv).
correct_poscat(15916,5,apprart).
correct_poscat(15981,20,adv).
correct_poscat(16031,5,appr).
correct_poscat(16031,501,pp).
correct_poscat(16167,500,np).
correct_poscat(16167,501,np).
correct_poscat(16200,27,adv).
correct_poscat(16274,8,adv).
correct_poscat(16294,6,adv).
correct_poscat(16348,2,adv).
correct_poscat(16360,5,adv).
correct_poscat(16450,9,ptkvz).
correct_poscat(16483,8,pds).
correct_poscat(16552,38,appr).
correct_poscat(16552,511,pp).
correct_poscat(16563,16,kous).
correct_poscat(16675,34,adv).
correct_poscat(16787,39,adjd).
correct_poscat(16787,507,ap).
correct_poscat(16802,12,adv).
correct_poscat(16910,2,adv).
correct_poscat(16927,6,adv).
correct_poscat(16966,2,adv).
correct_poscat(16979,38,pis).
correct_poscat(17002,509,isu).
correct_poscat(17125,21,pposs).
correct_poscat(17201,9,pposs).
correct_poscat(17232,30,adv).
correct_poscat(17246,34,pds).
correct_poscat(17275,9,adv).
correct_poscat(17476,2,adv).
correct_poscat(17502,18,adv).
correct_poscat(17503,7,adv).
correct_poscat(17504,3,adv).
correct_poscat(17509,3,adv).
correct_poscat(17509,6,adv).
correct_poscat(17524,10,adv).
correct_poscat(17784,17,adv).
correct_poscat(17786,5,adv).
correct_poscat(17895,1,kokom).
correct_poscat(17915,27,adv).
correct_poscat(17915,37,apzr).
correct_poscat(17926,39,pis).
correct_poscat(17927,21,koui).
correct_poscat(17927,502,avp).
correct_poscat(18012,8,adv).
correct_poscat(18025,18,ptkvz).
correct_poscat(18068,6,adv).
correct_poscat(18098,16,adv).
correct_poscat(18115,29,adv).
correct_poscat(18139,11,adjd).
correct_poscat(18139,501,ap).
correct_poscat(18146,4,kokom).
correct_poscat(18225,28,koui).
correct_poscat(18225,505,avp).
correct_poscat(18310,12,appr).
correct_poscat(18475,6,adv).
correct_poscat(18540,5,kokom).
correct_poscat(18631,6,adv).
correct_poscat(18668,18,adv).
correct_poscat(18674,15,adv).
correct_poscat(18704,7,adv).
correct_poscat(18723,5,adv).
correct_poscat(18743,12,adv).
correct_poscat(18792,8,appr).
correct_poscat(18806,5,adv).
correct_poscat(18817,25,adv).
correct_poscat(19009,10,apzr).
correct_poscat(19031,11,adv).
correct_poscat(19070,505,vz).
correct_poscat(19083,9,adv).
correct_poscat(19085,12,adv).
correct_poscat(19098,7,adv).
correct_poscat(19183,11,ptkvz).
correct_poscat(19401,7,appr).
correct_poscat(19401,8,appr).
correct_poscat(19408,13,adjd).
correct_poscat(19539,15,adv).
correct_poscat(19613,18,adv).
correct_poscat(19626,2,ne).
correct_poscat(19626,11,adv).
correct_poscat(19627,10,adv).
correct_poscat(19628,10,adv).
correct_poscat(19722,10,adv).
correct_poscat(19722,2,adv).
correct_poscat(19781,7,adv).
correct_poscat(19784,9,adv).
correct_poscat(19803,4,ptkvz).
correct_poscat(19985,4,nn).
correct_poscat(19992,29,adjd).
correct_poscat(20032,4,kous).
correct_poscat(20041,19,ptkvz).
correct_poscat(20065,501,avp).
correct_poscat(20131,9,adv).
correct_poscat(20181,25,adv).
correct_poscat(20195,9,adjd).
correct_poscat(20204,506,avp).
correct_poscat(20298,502,ap).
correct_poscat(20305,503,vz).
correct_poscat(20384,17,adv).
correct_poscat(20433,2,adv).
correct_poscat(20458,8,adv).
correct_poscat(20460,10,appr).
correct_poscat(20460,502,pp).
correct_poscat(20461,16,adv).
correct_poscat(20508,11,adv).
correct_poscat(20510,46,proav).
correct_poscat(20516,11,adv).
correct_poscat(20683,7,adv).
correct_poscat(20685,14,adv).
correct_poscat(20689,14,adv).
correct_poscat(20690,13,adv).
correct_poscat(20742,25,adv).
correct_poscat(20749,11,adv).
correct_poscat(20750,2,adv).
correct_poscat(20787,12,ne).
correct_poscat(20790,1,adv).
correct_poscat(20842,11,adv).
correct_poscat(20843,18,adv).
correct_poscat(20901,17,adv).
correct_poscat(20929,23,ne).
correct_poscat(21075,11,adv).
correct_poscat(21080,2,adv).
correct_poscat(21100,6,adv).
correct_poscat(21102,2,adv).
correct_poscat(21232,14,adv).
correct_poscat(21300,16,adv).
correct_poscat(21308,17,adv).
correct_poscat(21331,15,adv).
correct_poscat(21376,5,adv).
correct_poscat(21434,2,adv).
correct_poscat(21441,10,adv).
correct_poscat(21470,8,adv).
correct_poscat(21471,12,adv).
correct_poscat(21541,7,adjd).
correct_poscat(21558,10,adv).
correct_poscat(21676,5,appr).
correct_poscat(21676,511,pp).
correct_poscat(21728,2,adv).
correct_poscat(21733,18,adv).
correct_poscat(21812,15,adv).
correct_poscat(21881,25,adjd).
correct_poscat(21881,504,ap).
correct_poscat(21886,4,adv).
correct_poscat(21894,17,pis).
correct_poscat(21920,4,adjd).
correct_poscat(22172,7,adv).
correct_poscat(22247,503,np).
correct_poscat(22322,502,np).
correct_poscat(22372,14,adv).
correct_poscat(22377,12,adv).
correct_poscat(22243,42,appr).
correct_poscat(22243,43,nn).
correct_poscat(22420,5,prf).
correct_poscat(22471,23,appr).
correct_poscat(22476,10,adv).
correct_poscat(22476,502,avp).
correct_poscat(22490,18,adv).
correct_poscat(22494,8,adv).
correct_poscat(22494,17,adv).
correct_poscat(22494,18,kon).
correct_poscat(22494,19,adv).
correct_poscat(22494,503,cavp).
correct_poscat(22496,13,adv).
correct_poscat(22498,24,adv).
correct_poscat(22498,505,np).
correct_poscat(22521,21,adv).
correct_poscat(22529,2,pis).
correct_poscat(22529,500,aa).
correct_poscat(22638,10,pis).
correct_poscat(22664,20,adv).
correct_poscat(22669,27,adv).
correct_poscat(22718,3,adv).
correct_poscat(22728,18,adv).
correct_poscat(22736,22,adjd).
correct_poscat(22768,21,proav).
correct_poscat(22780,1,proav).
correct_poscat(22782,7,proav).
correct_poscat(22804,12,proav).
correct_poscat(22816,504,ap).
correct_poscat(22975,3,adv).
correct_poscat(22976,501,ap).
correct_poscat(22977,500,ap).
correct_poscat(22981,13,adv).
correct_poscat(22992,4,adv).
correct_poscat(22997,30,proav).
correct_poscat(23048,33,appr).
correct_poscat(23048,507,pp).
correct_poscat(23050,502,aa).
correct_poscat(23069,3,proav).
correct_poscat(23088,12,appr).
correct_poscat(23088,502,pp).
correct_poscat(23103,4,proav).
correct_poscat(23138,22,proav).
correct_poscat(23153,8,adv).
correct_poscat(23159,6,proav).
correct_poscat(23206,4,adv).
correct_poscat(23206,6,adv).
correct_poscat(23206,23,appr).
correct_poscat(23206,504,pp).
correct_poscat(23206,501,cavp).
correct_poscat(23217,15,appr).
correct_poscat(23217,503,pp).
correct_poscat(23248,8,proav).
correct_poscat(23300,506,ap).
correct_poscat(23300,510,cap).
correct_poscat(23361,21,pds).
correct_poscat(23371,1,proav).
correct_poscat(23386,8,adv).
correct_poscat(23456,12,pis).
correct_poscat(23488,4,adv).
correct_poscat(23488,506,avp).
correct_poscat(23494,7,apzr).
correct_poscat(23547,1,proav).
correct_poscat(23547,6,adv).
correct_poscat(23586,4,proav).
correct_poscat(23599,5,adv).
correct_poscat(23615,2,pis).
correct_poscat(23618,11,adv).
correct_poscat(23629,10,ptkzu).
correct_poscat(23629,501,vz).
correct_poscat(23655,8,adv).
correct_poscat(23660,2,proav).
correct_poscat(23660,500,s).
correct_poscat(23705,19,ptkvz).
correct_poscat(23705,21,adv).
correct_poscat(23721,1,proav).
correct_poscat(23891,17,adv).
correct_poscat(23892,5,adv).
correct_poscat(24004,39,vvinf).
correct_poscat(24145,5,adv).
correct_poscat(24160,17,adv).
correct_poscat(24194,9,adv).
correct_poscat(24316,23,vvinf).
correct_poscat(24374,19,adv).
correct_poscat(24476,12,adv).
correct_poscat(24476,503,avp).
correct_poscat(24478,8,adv).
correct_poscat(24494,10,adv).
correct_poscat(24527,3,appr).
correct_poscat(24527,500,pp).
correct_poscat(24617,7,adv).
correct_poscat(24627,2,adv).
correct_poscat(24790,16,adv).
correct_poscat(24971,39,adv).
correct_poscat(25024,17,apzr).
correct_poscat(25120,21,adv).
correct_poscat(25196,12,adv).
correct_poscat(25262,6,adv).
correct_poscat(25399,7,adv).
correct_poscat(25492,15,adv).
correct_poscat(25505,9,adv).
correct_poscat(25507,12,adv).
correct_poscat(25547,4,adv).
correct_poscat(25571,15,adv).
correct_poscat(25592,2,adv).
correct_poscat(25643,3,adv).
correct_poscat(25698,19,adv).
correct_poscat(25724,11,adv).
correct_poscat(25744,19,adv).
correct_poscat(25754,10,adv).
correct_poscat(25767,13,adv).
correct_poscat(25877,6,adv).
correct_poscat(25932,19,adv).
correct_poscat(25940,9,adv).
correct_poscat(26022,16,adv).
correct_poscat(26043,8,adv).
correct_poscat(26086,18,adja).
correct_poscat(26232,8,adjd).
correct_poscat(26234,13,adjd).
correct_poscat(26396,8,adv).
correct_poscat(26406,14,adv).
correct_poscat(26638,7,ptkvz).
correct_poscat(26710,15,prels).
correct_poscat(26710,512,cap).
correct_poscat(26710,507,ap).
correct_poscat(26729,13,adv).
correct_poscat(26763,515,ap).
correct_poscat(26952,19,vvfin).
correct_poscat(26971,5,adv).
correct_poscat(27054,5,adv).
correct_poscat(27054,16,pwav).
correct_poscat(27144,10,adv).
correct_poscat(27151,11,adv).
correct_poscat(27191,11,adv).
correct_poscat(27198,3,adv).
correct_poscat(27211,12,adv).
correct_poscat(27238,12,pdat).
correct_poscat(27253,3,adjd).
correct_poscat(27253,4,nn).
correct_poscat(27253,500,ap).
correct_poscat(27302,12,adv).
correct_poscat(27316,10,adv).
correct_poscat(27320,35,adv).
correct_poscat(27471,25,adv).
correct_poscat(27473,19,adv).
correct_poscat(27538,8,adv).
correct_poscat(27543,12,adv).
correct_poscat(27548,16,nn).
correct_poscat(27549,22,adv).
correct_poscat(27550,22,adv).
correct_poscat(27573,2,adv).
correct_poscat(27764,12,adv).
correct_poscat(27811,13,adv).
correct_poscat(27812,22,adv).
correct_poscat(27818,5,adv).
correct_poscat(28054,1,pis).
correct_poscat(28185,5,adv).
correct_poscat(28186,19,adv).
correct_poscat(28297,12,adv).
correct_poscat(28306,18,adv).
correct_poscat(28306,22,adv).
correct_poscat(28310,15,adv).
correct_poscat(28312,6,adv).
correct_poscat(28312,16,adv).
correct_poscat(28342,6,adv).
correct_poscat(28405,10,adv).
correct_poscat(28450,8,adv).
correct_poscat(28463,24,nn).
correct_poscat(28484,21,adv).
correct_poscat(28548,11,adv).
correct_poscat(28561,22,pwav).
correct_poscat(28613,505,ap).
correct_poscat(28743,3,adv).
correct_poscat(28793,10,pwav).
correct_poscat(28872,16,adv).
correct_poscat(28873,38,adv).
correct_poscat(28908,13,adv).
correct_poscat(28981,11,adv).
correct_poscat(28981,4,adv).
correct_poscat(29026,11,adv).
correct_poscat(29098,9,adv).
correct_poscat(29147,5,adv).
correct_poscat(29148,12,adv).
correct_poscat(29353,503,np).
correct_poscat(29372,4,card).
correct_poscat(29372,5,card).
correct_poscat(29547,4,adv).
correct_poscat(29590,12,pwav).
correct_poscat(29598,6,adv).
correct_poscat(29685,6,adv).
correct_poscat(29706,4,adv).
correct_poscat(29711,9,adv).
correct_poscat(29731,18,adv).
correct_poscat(29771,4,pis).
correct_poscat(29777,16,adv).
correct_poscat(29778,11,adv).
correct_poscat(29781,26,pwav).
correct_poscat(29786,11,adv).
correct_poscat(29790,17,pwav).
correct_poscat(29800,21,adv).
correct_poscat(29825,25,adv).
correct_poscat(29832,18,adv).
correct_poscat(29865,6,adv).
correct_poscat(29917,16,pwav).
correct_poscat(29919,5,card). % 000. = tausendste
correct_poscat(29957,13,adv).
correct_poscat(29958,6,adja).
correct_poscat(30028,4,adv).
correct_poscat(30038,7,adv).
correct_poscat(30066,14,nn).
correct_poscat(30132,1,pis).
correct_poscat(30136,7,adv).
correct_poscat(30153,23,adjd).
correct_poscat(30177,11,adv).
correct_poscat(30177,26,adv).
correct_poscat(30187,13,adv).
correct_poscat(30192,9,adv).
correct_poscat(30244,4,appr).
correct_poscat(30244,500,pp).
correct_poscat(30251,5,adv).
correct_poscat(30323,10,nn).
correct_poscat(30323,12,nn).
correct_poscat(30499,7,adja).
correct_poscat(30667,11,adv).
correct_poscat(30764,1,pds).
correct_poscat(30863,21,adv).
correct_poscat(30864,11,adv).
correct_poscat(31047,7,adv).
correct_poscat(31080,8,adv).
correct_poscat(31110,5,pdat).
correct_poscat(31162,5,adv).
correct_poscat(31467,16,adjd).
correct_poscat(31482,11,adv).
correct_poscat(31482,504,avp).
correct_poscat(31536,5,adv).
correct_poscat(31536,501,avp).
correct_poscat(31539,503,avp).
correct_poscat(31753,18,appr).
correct_poscat(31753,505,pp).
correct_poscat(31757,7,nn).
correct_poscat(32078,12,adv).
correct_poscat(32079,9,adv).
correct_poscat(32119,28,ptkvz).
correct_poscat(32145,501,cap).
correct_poscat(32331,1,adv).
correct_poscat(32515,31,adv).
correct_poscat(32619,10,adjd).
correct_poscat(32625,8,adv).
correct_poscat(32755,3,adv).
correct_poscat(32770,4,prf).
correct_poscat(32919,14,adv).
correct_poscat(33054,11,ptkvz).
correct_poscat(33058,7,adv).
correct_poscat(33098,2,vafin).
correct_poscat(33230,9,adv).
correct_poscat(33249,7,nn).
correct_poscat(33264,500,avp).
correct_poscat(33523,24,ptkvz).
correct_poscat(33556,503,aa).
correct_poscat(33597,503,ap).
correct_poscat(33667,13,nn). %
correct_poscat(33728,4,pdat).
correct_poscat(33739,7,pds).
correct_poscat(33784,12,appr).
correct_poscat(33784,502,pp).
correct_poscat(33784,506,cpp).
correct_poscat(33806,9,appr).
correct_poscat(33806,502,pp).
correct_poscat(33806,503,cpp).
correct_poscat(34028,1,pis).
correct_poscat(34050,7,adv).
correct_poscat(34084,16,adv).
correct_poscat(34086,21,vvpp).
correct_poscat(34094,1,pds).
correct_poscat(34164,26,adjd).
correct_poscat(34166,32,adjd).
correct_poscat(34169,9,ptkvz).
correct_poscat(34400,7,appr).
correct_poscat(34400,502,pp).
correct_poscat(34629,3,adv).
correct_poscat(34677,505,aa).
correct_poscat(34757,10,adjd).
correct_poscat(34870,502,avp).
correct_poscat(34938,31,vvinf).
correct_poscat(35080,5,adv).
correct_poscat(35145,6,adv).
correct_poscat(35150,8,adv).
correct_poscat(35220,3,adv).
correct_poscat(35305,6,adv).
correct_poscat(35352,5,adv).
correct_poscat(35389,16,adv).
correct_poscat(35426,20,adjd).
correct_poscat(35438,18,adv).
correct_poscat(35547,9,adv).
correct_poscat(35560,9,adv).
correct_poscat(35563,6,adv).
correct_poscat(35582,13,adv).
correct_poscat(35863,14,adv).
correct_poscat(35868,10,adv).
correct_poscat(35999,5,proav).
correct_poscat(36019,44,adv).
correct_poscat(36021,3,adv).
correct_poscat(36040,15,pds).
correct_poscat(36086,3,appr).
correct_poscat(36086,500,pp).
correct_poscat(36238,4,adv).
correct_poscat(36278,16,adv).
correct_poscat(36278,7,adv).
correct_poscat(36310,10,adv).
correct_poscat(36313,7,adv).
correct_poscat(36470,6,adv).
correct_poscat(36513,10,adv).
correct_poscat(36513,6,adv).
correct_poscat(36544,18,adv).
correct_poscat(36545,16,adv).
correct_poscat(36546,7,adv).
correct_poscat(36571,4,adv).
correct_poscat(36575,7,adv).
correct_poscat(36625,5,adv).
correct_poscat(36644,7,adv).
correct_poscat(36654,38,adv).
correct_poscat(36679,5,adv).
correct_poscat(36698,12,adv).
correct_poscat(36698,6,adv).
correct_poscat(36708,6,adv).
correct_poscat(36709,7,adv).
correct_poscat(36710,12,adv).
correct_poscat(36715,17,adv).
correct_poscat(36731,10,adv).
correct_poscat(36795,3,adv).
correct_poscat(36812,19,adv).
correct_poscat(36827,21,adv).
correct_poscat(36831,8,adv).
correct_poscat(36838,5,adv).
correct_poscat(36856,19,ptkvz).
correct_poscat(36864,7,adv).
correct_poscat(36885,3,adv).
correct_poscat(36889,8,adv).
correct_poscat(36905,20,koui).
correct_poscat(36905,504,avp).
correct_poscat(36919,17,adv).
correct_poscat(36940,30,adv).
correct_poscat(36945,11,adv).
correct_poscat(36957,9,adv).
correct_poscat(36969,13,adv).
correct_poscat(36976,10,pper).
correct_poscat(36998,16,adv).
correct_poscat(37049,22,adv).
correct_poscat(37064,25,adv).
correct_poscat(37108,5,adv).
correct_poscat(37109,14,adv).
correct_poscat(37132,15,adv).
correct_poscat(37143,11,vvinf).
correct_poscat(37198,32,adv).
correct_poscat(37198,36,adv).
correct_poscat(37238,7,adv).
correct_poscat(37239,12,adv).
correct_poscat(37251,9,adv).
correct_poscat(37252,14,adv).
correct_poscat(37283,34,adv).
correct_poscat(37287,21,adv).
correct_poscat(37307,12,adv).
correct_poscat(37318,16,adv).
correct_poscat(37318,8,adv).
correct_poscat(37344,5,ptkvz).
correct_poscat(37350,16,adv).
correct_poscat(37377,13,adv).
correct_poscat(37387,27,adv).
correct_poscat(37448,12,adv).
correct_poscat(37448,20,adv).
correct_poscat(37471,21,adv).
correct_poscat(37490,4,adv).
correct_poscat(37504,27,adv).
correct_poscat(37509,16,adv).
correct_poscat(37512,18,adv).
correct_poscat(37516,9,adv).
correct_poscat(37557,15,adv).
correct_poscat(37582,8,adv).
correct_poscat(37584,14,adv).
correct_poscat(37590,18,adv).
correct_poscat(37642,503,pp).
correct_poscat(37754,10,adv).
correct_poscat(37759,2,adv).
correct_poscat(37725,15,appr).
correct_poscat(37725,506,pp).
correct_poscat(37804,18,adv).
correct_poscat(37807,4,adv).
correct_poscat(37894,12,adv).
correct_poscat(37926,3,adv).
correct_poscat(37929,10,adv).
correct_poscat(37952,16,adv).
correct_poscat(38011,13,adv).
correct_poscat(38078,5,adv).
correct_poscat(38101,8,adv).
correct_poscat(38104,12,adv).
correct_poscat(38104,16,adv).
correct_poscat(38105,8,adv).
correct_poscat(38114,18,adv).
correct_poscat(38115,12,adv).
correct_poscat(38116,3,adv).
correct_poscat(38119,5,adv).
correct_poscat(38125,35,adv).
correct_poscat(38243,13,adv).
correct_poscat(38275,6,adv).
correct_poscat(38327,4,adv).
correct_poscat(38328,9,adv).
correct_poscat(38331,20,adv).
correct_poscat(38332,10,adv).
correct_poscat(38333,10,adv).
correct_poscat(38334,2,adv).
correct_poscat(38381,11,adv).
correct_poscat(38389,10,adv).
correct_poscat(38543,9,adv).
correct_poscat(38544,23,adv).
correct_poscat(38627,15,adv).
correct_poscat(38662,19,adv).
correct_poscat(38682,3,vvfin).
correct_poscat(38682,503,s).
correct_poscat(38829,2,adv).
correct_poscat(38837,3,adv).
correct_poscat(38865,5,adv).
correct_poscat(38894,13,adv).
correct_poscat(38909,4,adv).
correct_poscat(38922,23,adv).
correct_poscat(38923,10,adv).
correct_poscat(38961,5,adv).
correct_poscat(39014,3,adv).
correct_poscat(39014,500,avp).
correct_poscat(39030,12,adv).
correct_poscat(39031,15,nn).
correct_poscat(39066,31,adv).
correct_poscat(39072,22,adv).
correct_poscat(39074,13,adv).
correct_poscat(39400,10,prels).
correct_poscat(39080,5,ptkvz).
correct_poscat(39099,3,adv).
correct_poscat(39101,4,adv).
correct_poscat(39151,14,adv).
correct_poscat(39163,14,adv).
correct_poscat(39164,12,adv).
correct_poscat(39208,4,adv).
correct_poscat(39224,11,adv).
correct_poscat(39226,6,adv).
correct_poscat(39230,16,adv).
correct_poscat(39233,12,adv).
correct_poscat(39250,10,adv).
correct_poscat(39262,17,adv).
correct_poscat(39272,11,adv).
correct_poscat(39307,21,adv).
correct_poscat(39308,6,adv).
correct_poscat(39337,21,adv).
correct_poscat(39337,28,nn).
correct_poscat(39348,10,adv).
correct_poscat(39361,18,adv).
correct_poscat(39361,27,adv).
correct_poscat(39392,12,adv).
correct_poscat(39426,7,adv).
correct_poscat(39432,17,nn).
correct_poscat(39452,33,adv).
correct_poscat(39454,3,adv).
correct_poscat(39472,22,adv).
correct_poscat(39484,8,adv).
correct_poscat(39507,20,adv).
correct_poscat(39519,16,adv).
correct_poscat(39520,17,adv).
correct_poscat(39534,7,adv).
correct_poscat(39584,11,adv).
correct_poscat(39594,8,adv).
correct_poscat(39601,11,adv).
correct_poscat(39609,28,adv).
correct_poscat(39636,6,adv).
correct_poscat(39648,23,adv).
correct_poscat(39689,7,adv).
correct_poscat(39705,6,adv).
correct_poscat(39752,9,nn).
correct_poscat(39899,8,ptkvz).
correct_poscat(39904,25,adv).
correct_poscat(39910,19,adv).
correct_poscat(39939,16,adv).
correct_poscat(39987,10,adv).
correct_poscat(40017,10,adv).
correct_poscat(40020,10,adv).
correct_poscat(40022,14,adv).
correct_poscat(40023,15,adv).
correct_poscat(40023,8,adv).
correct_poscat(40032,19,adv).
correct_poscat(40033,5,adv).
correct_poscat(40034,4,adv).
correct_poscat(40049,6,adv).
correct_poscat(40060,10,adv).
correct_poscat(40075,10,adv).
correct_poscat(40099,9,adv).
correct_poscat(40205,7,adv).
correct_poscat(40244,12,adv).
correct_poscat(40250,18,adv).
correct_poscat(40250,30,adv).
correct_poscat(40253,16,adv).
correct_poscat(40288,4,prels).
correct_poscat(40310,2,adv).
correct_poscat(40323,5,adv).
correct_poscat(40325,9,adv).
correct_poscat(40328,9,adv).
correct_poscat(40339,15,adv).
correct_poscat(40362,15,adv).
correct_poscat(40376,11,adv).
correct_poscat(40413,12,adv).
correct_poscat(40421,15,adv).
correct_poscat(40444,9,adv).
correct_poscat(40448,19,adv).
correct_poscat(40457,15,adv).
correct_poscat(40458,13,adv).
correct_poscat(40458,6,adv).
correct_poscat(40467,6,adv).
correct_poscat(40468,3,adv).
correct_poscat(40476,6,adv).
correct_poscat(40484,9,vvinf).
correct_poscat(40497,2,adv).
correct_poscat(40497,8,adv).
correct_poscat(40499,10,apzr).
correct_poscat(40507,23,adv).
correct_poscat(40537,5,adv).
correct_poscat(40617,8,adv).
correct_poscat(40630,2,adv).
correct_poscat(40630,21,adv).
correct_poscat(40702,21,adv).
correct_poscat(40703,17,adv).
correct_poscat(40718,9,adv).
correct_poscat(40737,8,adv).
correct_poscat(40739,8,adv).
correct_poscat(40746,6,adv).
correct_poscat(40750,13,adv).
correct_poscat(40755,12,adjd).
correct_poscat(40785,17,adv).
correct_poscat(40796,4,adv).
correct_poscat(40807,8,adv).
correct_poscat(40814,2,adv).
correct_poscat(40822,19,adv).
correct_poscat(40832,14,adv).
correct_poscat(40835,500,avp).
correct_poscat(40835,7,adv).
correct_poscat(40837,5,adv).
correct_poscat(40909,11,adv).
correct_poscat(40920,12,adv).
correct_poscat(40958,25,adv).
correct_poscat(40960,10,adv).
correct_poscat(41002,8,adv).
%correct_poscat(41004,2,vvpp).
correct_poscat(41005,14,adv).
correct_poscat(41005,22,adv).
correct_poscat(41031,21,adv).
correct_poscat(41032,9,adv).
correct_poscat(41051,14,adv).
correct_poscat(41075,23,adv).
correct_poscat(41075,28,adv).
correct_poscat(41076,24,adv).
correct_poscat(41080,18,pwav).
correct_poscat(41088,10,adv).
correct_poscat(41123,10,adv).
correct_poscat(41127,6,adv).
correct_poscat(41140,16,adv).
correct_poscat(41143,12,adjd).
correct_poscat(41151,18,adv).
correct_poscat(41153,16,adv).
correct_poscat(41172,5,adv).
correct_poscat(41191,24,adv).
correct_poscat(41219,5,adv).
correct_poscat(41227,15,adv).
correct_poscat(41267,12,adv).
correct_poscat(41278,22,adv).
correct_poscat(41287,16,kokom).
correct_poscat(41303,6,art).
correct_poscat(41313,23,adv).
correct_poscat(41321,11,adv).
correct_poscat(41325,12,adv).
correct_poscat(41325,15,pwav).
correct_poscat(41356,1,adv).
correct_poscat(41360,7,adv).
correct_poscat(41390,18,adv).
correct_poscat(41390,6,adv).
correct_poscat(41401,11,adv).
correct_poscat(41412,27,pds).
correct_poscat(41415,53,adv).
correct_poscat(41454,14,adv).
correct_poscat(41523,9,adv).
correct_poscat(41540,11,adv).
correct_poscat(41544,13,adv).
correct_poscat(41544,8,adv).
correct_poscat(41583,7,pds).
correct_poscat(41597,4,adv).
correct_poscat(41628,5,adv).
correct_poscat(41629,9,adv).
correct_poscat(41634,16,adv).
correct_poscat(41659,12,adv).
correct_poscat(41665,5,adv).
correct_poscat(41684,6,adv).
correct_poscat(41686,7,pis).
correct_poscat(41686,10,adv).
correct_poscat(41686,501,np).
correct_poscat(41716,13,adv).
correct_poscat(41721,23,adv).
correct_poscat(41725,6,adv).
correct_poscat(41748,23,pds).
correct_poscat(41757,13,adv).
correct_poscat(41771,9,adv).
correct_poscat(41775,12,adv).
correct_poscat(41786,8,adv).
correct_poscat(41804,9,pdat).
correct_poscat(41816,18,adv).
correct_poscat(41816,19,adv).
correct_poscat(41816,20,card).
correct_poscat(41819,15,pds).
correct_poscat(41844,22,adv).
correct_poscat(41845,15,adv).
correct_poscat(41887,9,adv).
correct_poscat(41904,6,adv).
correct_poscat(41909,22,adv).
correct_poscat(41922,3,adv).
correct_poscat(41951,27,appo).
correct_poscat(41955,7,adv).
correct_poscat(41957,17,pis).
correct_poscat(41978,6,ptkvz).
correct_poscat(41980,4,adv).
correct_poscat(41992,18,adv).
correct_poscat(42048,13,adv).
correct_poscat(42091,3,adv).
correct_poscat(42107,10,pwav).
correct_poscat(42153,18,adv).
correct_poscat(42158,9,vvpp).
correct_poscat(42185,21,pis).
correct_poscat(42194,3,adv).
correct_poscat(42194,4,adv).
correct_poscat(42219,25,adv).
correct_poscat(42238,7,adv).
correct_poscat(42247,22,adv).
correct_poscat(42282,2,adv).
correct_poscat(42286,7,adv).
correct_poscat(42296,7,adv).
correct_poscat(42300,7,adv).
correct_poscat(42304,1,vvpp).
correct_poscat(42304,508,vp).
correct_poscat(42328,5,adv).
correct_poscat(42361,19,adv).
correct_poscat(42361,503,avp).
correct_poscat(42368,16,adv).
correct_poscat(42368,9,adv).
correct_poscat(42369,11,adv).
correct_poscat(42398,8,adv).
correct_poscat(42398,9,adv).
correct_poscat(42398,5,pis).
correct_poscat(42410,25,adv).
correct_poscat(42411,10,adv).
correct_poscat(42440,5,adv).
correct_poscat(42445,11,adv).
correct_poscat(42483,27,adv).
correct_poscat(42509,17,adv).
correct_poscat(42510,4,adv).
correct_poscat(42518,8,adv).
correct_poscat(42525,2,adv).
correct_poscat(42528,6,adv).
correct_poscat(42574,12,adv).
correct_poscat(42584,25,adv).
correct_poscat(42591,3,adv).
correct_poscat(42593,5,adv).
correct_poscat(42595,14,adv).
correct_poscat(42609,7,adv).
correct_poscat(42623,7,adv).
correct_poscat(42654,2,adv).
correct_poscat(42799,8,adv).
correct_poscat(42809,18,adv).
correct_poscat(42820,15,adv).
correct_poscat(42820,8,adv).
correct_poscat(42824,14,adv).
correct_poscat(42841,3,adv).
correct_poscat(42873,5,adv).
correct_poscat(42875,15,adv).
correct_poscat(42899,13,adv).
correct_poscat(42908,9,adv).
correct_poscat(42999,1,vvpp).
correct_poscat(42999,507,vp).
correct_poscat(43005,13,adv).
correct_poscat(43005,15,pds).
correct_poscat(43014,5,adv).
correct_poscat(43018,16,adv).
correct_poscat(43018,22,adv).
correct_poscat(43025,2,adv).
correct_poscat(43051,5,adv).
correct_poscat(43052,6,adv).
correct_poscat(43052,17,pwav).
correct_poscat(43092,4,adv).
correct_poscat(43110,11,adv).
correct_poscat(43112,9,adv).
correct_poscat(43113,16,adv).
correct_poscat(43129,13,adv).
correct_poscat(43137,21,adv).
correct_poscat(43139,8,adv).
correct_poscat(43139,9,adv).
correct_poscat(43139,504,np).
correct_poscat(43166,8,adv).
correct_poscat(43176,9,adv).
correct_poscat(43178,11,adv).
correct_poscat(43203,14,adv).
correct_poscat(43220,3,adv).
correct_poscat(43249,6,adv).
correct_poscat(43274,14,adv).
correct_poscat(43301,7,adv).
correct_poscat(43307,18,adv).
correct_poscat(43337,10,adv).
correct_poscat(43343,1,pds).
correct_poscat(43344,7,adv).
correct_poscat(43355,6,adv).
correct_poscat(43355,505,avp).
correct_poscat(43363,13,adv).
correct_poscat(43373,10,adv).
correct_poscat(43380,10,adv).
correct_poscat(43396,14,adv).
correct_poscat(43399,6,adv).
correct_poscat(43412,14,adv).
correct_poscat(43413,15,kon).
correct_poscat(43419,7,adv).
correct_poscat(43425,10,adv).
correct_poscat(43428,20,adv).
correct_poscat(43428,9,adv).
correct_poscat(43429,11,adv).
correct_poscat(43443,20,adv).
correct_poscat(43448,9,adv).
correct_poscat(43470,13,adv).
correct_poscat(43471,16,adv).
correct_poscat(43478,14,adv).
correct_poscat(43491,12,adv).
correct_poscat(43498,25,adv).
correct_poscat(43498,33,adv).
correct_poscat(43517,16,adv).
correct_poscat(43524,15,adv).
correct_poscat(43538,5,adv).
correct_poscat(43565,5,pis).
correct_poscat(43589,10,adv).
correct_poscat(43676,8,adv).
correct_poscat(43683,18,adv).
correct_poscat(43684,7,adv).
correct_poscat(43745,11,adv).
correct_poscat(43750,31,adv).
correct_poscat(43759,7,adv).
correct_poscat(43773,6,adv).
correct_poscat(43785,16,adv).
correct_poscat(43802,13,adv).
correct_poscat(43805,10,adv).
correct_poscat(43822,13,adv).
correct_poscat(43828,16,adv).
correct_poscat(43863,12,adv).
correct_poscat(43868,6,adv).
correct_poscat(43869,23,adv).
correct_poscat(43877,16,adv).
correct_poscat(43917,3,adv).
correct_poscat(43965,12,adv).
correct_poscat(43969,6,adv).
correct_poscat(43971,12,adv).
correct_poscat(43991,8,adv).
correct_poscat(44015,24,adv).
correct_poscat(44019,26,adv).
correct_poscat(44023,18,adv).
correct_poscat(44029,22,art).
correct_poscat(44033,5,adv).
correct_poscat(44035,22,adv).
correct_poscat(44036,13,kon).
correct_poscat(44049,3,art).
correct_poscat(44073,14,adv).
correct_poscat(44074,19,adv).
correct_poscat(44081,5,adv).
correct_poscat(44098,13,adv).
correct_poscat(44113,7,adv).
correct_poscat(44115,509,s).
correct_poscat(44145,26,adv).
correct_poscat(44201,12,adv).
correct_poscat(44266,4,adv).
correct_poscat(44296,17,adv).
correct_poscat(44306,10,adv).
correct_poscat(44306,5,adv).
correct_poscat(44315,8,adv).
correct_poscat(44321,3,adv).
correct_poscat(44330,12,adv).
correct_poscat(44331,12,adv).
correct_poscat(44384,10,adv).
correct_poscat(44387,13,adv).
correct_poscat(44387,5,adv).
correct_poscat(44509,10,adv).
correct_poscat(44517,8,adv).
correct_poscat(44518,5,adv).
correct_poscat(44630,23,adv).
correct_poscat(44636,20,adv).
correct_poscat(44679,1,nn).
correct_poscat(44696,14,adv).
correct_poscat(44739,4,adv).
correct_poscat(44758,26,adv).
correct_poscat(44783,7,adv).
correct_poscat(44884,21,adv).
correct_poscat(44902,12,adv).
correct_poscat(44912,5,adv).
correct_poscat(44947,6,adv).
correct_poscat(45109,10,adv).
correct_poscat(45109,11,adv).
correct_poscat(45109,501,np).
correct_poscat(45156,8,adv).
correct_poscat(45307,12,adv).
correct_poscat(45392,10,adv).
correct_poscat(45402,28,pds).
correct_poscat(45438,5,adv).
correct_poscat(45440,25,adv).
correct_poscat(45456,12,adv).
correct_poscat(45529,12,adv).
correct_poscat(45546,3,adv).
correct_poscat(45640,11,nn).
correct_poscat(45670,11,adv).
correct_poscat(45759,21,adjd).
correct_poscat(45768,13,adv).
correct_poscat(45768,28,pwav).
correct_poscat(45780,6,adv).
correct_poscat(45782,4,adv).
correct_poscat(45788,18,adv).
correct_poscat(45798,8,adv).
correct_poscat(45859,2,adv).
correct_poscat(45929,31,adv).
correct_poscat(46015,11,adv).
correct_poscat(46152,6,adv).
correct_poscat(46178,507,pp).
correct_poscat(46244,7,pis).
correct_poscat(46380,17,adv).
correct_poscat(46431,20,adv).
correct_poscat(46549,31,adv).
correct_poscat(46627,21,adv).
correct_poscat(46771,23,adv).
correct_poscat(46845,3,adv).
correct_poscat(46879,9,appr).
correct_poscat(46879,501,pp).
correct_poscat(46939,8,adv).
correct_poscat(46953,2,adv).
correct_poscat(47092,6,adv).
correct_poscat(47154,48,adv).
correct_poscat(47216,53,adv).
correct_poscat(47252,502,s).
correct_poscat(47262,15,adv).
correct_poscat(47265,5,adv).
correct_poscat(47267,4,adv).
correct_poscat(47268,4,adv).
correct_poscat(47277,17,adv).
correct_poscat(47400,20,adv).
correct_poscat(47597,28,adv).
correct_poscat(47804,11,adv).
correct_poscat(47949,501,avp).
correct_poscat(48017,19,apzr).
correct_poscat(48117,40,adv).
correct_poscat(48152,3,adv).
correct_poscat(48185,17,adv).
correct_poscat(48242,8,adv).
correct_poscat(48289,5,pis).
correct_poscat(48362,21,nn).
correct_poscat(48531,21,vminf).
correct_poscat(48556,509,np).
correct_poscat(48559,5,pis).
correct_poscat(48591,7,pis).
correct_poscat(48676,14,pds).
correct_poscat(48730,13,pds).
correct_poscat(48732,1,adjd).
correct_poscat(48778,16,proav).
correct_poscat(48924,3,adja).
correct_poscat(49022,62,pis).
correct_poscat(49022,549,np).
correct_poscat(49087,7,adv).
correct_poscat(49092,500,np).
correct_poscat(49092,501,np).
correct_poscat(49170,503,np).
correct_poscat(49170,504,np).
correct_poscat(49208,21,adv).
correct_poscat(49311,9,ptkvz).
correct_poscat(49373,501,np).
correct_poscat(49373,502,np).
correct_poscat(49373,503,np).
correct_poscat(49373,504,cnp).
correct_poscat(49405,28,adv).
correct_poscat(49408,506,pp).
correct_poscat(49428,501,np).
correct_poscat(49428,503,np).
correct_poscat(49462,13,pds).
correct_poscat(49517,11,ptkvz).
correct_poscat(49597,7,adv).
correct_poscat(49603,500,np).
correct_poscat(49603,501,np).
correct_poscat(49795,20,appr).
correct_poscat(49795,507,pp).
correct_poscat(49878,500,np).
correct_poscat(49878,501,np).
correct_poscat(49893,7,ptkvz).
correct_poscat(50024,20,pis).
correct_poscat(50024,26,pis).
correct_poscat(50040,13,pis).
correct_poscat(50049,500,np).
correct_poscat(50049,501,np).
correct_poscat(50049,502,np).
correct_poscat(50049,503,np).
correct_poscat(50049,504,cnp).
correct_poscat(50129,4,adjd).
correct_poscat(50180,500,np).
correct_poscat(50180,503,np).
correct_poscat(50180,505,np).
correct_poscat(50180,506,cnp).
correct_poscat(50227,21,adjd).
correct_poscat(50228,8,pper).
correct_poscat(50236,24,adjd).
correct_poscat(50236,503,aa).
correct_poscat(50358,15,pds).
correct_poscat(50404,7,nn).
correct_poscat(50427,20,adjd).
correct_poscat(50440,14,ptkvz).
correct_poscat(50445,24,pds).
correct_poscat(50469,3,adjd).


% bis in coordination should be tagged as KON
correct_poscat(3060,12,kon).
correct_poscat(3064,51,kon).
correct_poscat(3177,7,kon).
correct_poscat(3230,10,kon).
correct_poscat(3549,33,kon).
correct_poscat(3811,10,kon).
correct_poscat(10205,5,kon).
correct_poscat(11331,6,kon).
correct_poscat(11987,23,kon).
correct_poscat(12785,18,kon).
correct_poscat(13317,2,kon).
correct_poscat(18649,14,kon).
correct_poscat(19007,19,kon).
correct_poscat(22212,4,kon).
correct_poscat(22781,19,kon).
correct_poscat(22785,5,kon).
correct_poscat(22814,10,kon).
correct_poscat(23215,47,kon).
correct_poscat(23267,19,kon).
correct_poscat(23274,9,kon).
correct_poscat(23621,7,kon).
correct_poscat(23632,26,kon).
correct_poscat(23701,8,kon).
correct_poscat(25456,30,kon).
correct_poscat(27193,9,kon).
correct_poscat(29319,23,kon).
correct_poscat(30416,18,kon).
correct_poscat(30495,22,kon).
correct_poscat(30528,13,kon).
correct_poscat(30535,15,kon).
correct_poscat(30585,35,kon).
correct_poscat(31204,10,kon).
correct_poscat(31329,20,kon).
correct_poscat(31699,9,kon).
correct_poscat(31797,9,kon).
correct_poscat(31839,12,kon).
correct_poscat(31844,9,kon).
correct_poscat(31959,6,kon).
correct_poscat(32037,18,kon).
correct_poscat(32303,7,kon).
correct_poscat(32643,36,kon).
correct_poscat(32761,23,kon).
correct_poscat(32919,7,kon).
correct_poscat(32986,23,kon).
correct_poscat(33406,6,kon).
correct_poscat(33467,11,kon).
correct_poscat(34007,6,kon).
correct_poscat(34045,21,kon).
correct_poscat(34055,21,kon).
correct_poscat(34125,12,kon).
correct_poscat(34563,9,kon).
correct_poscat(40041,13,kon).
correct_poscat(40069,7,kon).
correct_poscat(40250,20,kon).
correct_poscat(40337,27,kon).
correct_poscat(40338,8,kon).
correct_poscat(40815,13,kon).
correct_poscat(40867,22,kon).
correct_poscat(40882,7,kon).
correct_poscat(41331,10,kon).
correct_poscat(41331,16,kon).
correct_poscat(42468,13,kon).
correct_poscat(42469,16,kon).
correct_poscat(42549,18,kon).
correct_poscat(44201,4,kon).
correct_poscat(46475,2,vafin).
correct_poscat(46477,4,vafin).
correct_poscat(47796,46,kon).
correct_poscat(48731,8,kon).
correct_poscat(48740,8,kon).
correct_poscat(49998,20,kon).
correct_poscat(50186,10,kon).
correct_poscat(50187,11,kon).
correct_poscat(50188,12,kon).
correct_poscat(50320,4,kon).

% später is tagged as adjd instead of adv
correct_poscat(4670,30,adjd).
correct_poscat(5504,53,adjd).
correct_poscat(9186,7,adjd).
correct_poscat(14994,13,adjd).
correct_poscat(23032,31,adjd).
correct_poscat(30307,8,adjd).
correct_poscat(30315,1,adjd).
correct_poscat(32534,31,adjd).
correct_poscat(34008,10,adjd).
correct_poscat(36818,29,adjd).
correct_poscat(42088,1,adjd).
correct_poscat(46416,28,adjd).
correct_poscat(46708,1,adjd).
correct_poscat(48425,15,adjd).
correct_poscat(48431,19,adjd).
correct_poscat(48433,4,adjd).
correct_poscat(48450,7,adjd).
correct_poscat(48560,4,adjd).
correct_poscat(48788,5,adjd).
correct_poscat(49010,7,adjd).
correct_poscat(49532,25,adjd).

correct_secedge_label(2695,3,503,sb).
correct_secedge_label(4167,3,505,hd).
correct_secedge_label(4305,3,506,hd).
correct_secedge_label(4305,10,501,hd).
correct_secedge_label(5574,3,509,hd).
correct_secedge_label(5574,16,500,hd).
correct_secedge_label(6989,4,511,hd).
correct_secedge_label(9157,4,508,hd).
correct_secedge_label(14837,6,507,hd).
correct_secedge_label(16215,12,504,pm).
correct_secedge_label(21838,19,511,sb).
correct_secedge_label(22009,7,507,cp).
correct_secedge_label(22103,22,507,mo).
correct_secedge_label(23080,517,513,mo).
correct_secedge_label(23515,17,505,sb).
correct_secedge_label(25375,2,507,cp).
correct_secedge_label(27487,13,512,cp).
correct_secedge_label(28348,17,513,hd).
correct_secedge_label(28705,6,507,cp).
correct_secedge_label(37891,4,508,hd).
correct_secedge_label(38890,5,509,hd).
correct_secedge_label(43476,500,510,sb).
correct_secedge_label(48447,503,505,mo).
correct_secedge_label(49534,504,500,oc).
correct_secedge_label(49817,8,509,cp).

unnecessary_node(933,512).
unnecessary_node(1195,515).
unnecessary_node(1435,501).
unnecessary_node(4171,502).
unnecessary_node(4942,506).
unnecessary_node(5552,504).
unnecessary_node(5871,501).
unnecessary_node(8219,503).
unnecessary_node(8963,500).
unnecessary_node(9185,501).
unnecessary_node(9195,508).
unnecessary_node(9261,507).
unnecessary_node(9397,508).
unnecessary_node(9577,507).
unnecessary_node(12325,501).
unnecessary_node(13768,502).
unnecessary_node(13768,504).
unnecessary_node(15789,503).
unnecessary_node(16552,513).
unnecessary_node(17002,505).
unnecessary_node(18517,500).
unnecessary_node(18268,504).
unnecessary_node(19171,502).
unnecessary_node(21289,502).
unnecessary_node(23274,502).
unnecessary_node(23728,502).
unnecessary_node(28622,522).
unnecessary_node(29897,506).
unnecessary_node(33287,501).
unnecessary_node(33806,501).
unnecessary_node(34757,501).
unnecessary_node(35221,521).
unnecessary_node(37725,503).
unnecessary_node(39119,500).
unnecessary_node(45002,501).
unnecessary_node(48997,503).
unnecessary_node(49406,501).
unnecessary_node(49408,502).
unnecessary_node(49459,510).
unnecessary_node(49795,502).
unnecessary_node(50404,501).

unnecessary_secedge(17200,501,509).
unnecessary_secedge(26710,15,507).
unnecessary_secedge(26710,36,511).
unnecessary_secedge(26710,510,507).
unnecessary_secedge(49406,2,501).
