manual_head(37,511,33).
manual_head(406,507,13). % actually wrong, would need a major restructuring
