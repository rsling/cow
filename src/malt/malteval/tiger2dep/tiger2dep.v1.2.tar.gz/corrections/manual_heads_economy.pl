manual_head(196,505,12).
manual_head(202,506,16).
manual_head(219,506,14).
manual_head(229,503,9). % probably wrong, but sentence doesn't make much sense
